/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Product, CartItem, Review } from './types';
import {
  FLAGSHIP_PRODUCT,
  RELATED_PRODUCTS,
  INITIAL_REVIEWS,
  GEAR_5_IMAGE,
} from './data/products';
import { Header } from './components/Header';
import { ProductDetail } from './components/ProductDetail';
import { EngineeringSection } from './components/EngineeringSection';
import { ReviewsSection } from './components/ReviewsSection';
import { RelatedProducts } from './components/RelatedProducts';
import { CartDrawer } from './components/CartDrawer';
import { SizeGuideModal } from './components/SizeGuideModal';
import { WriteReviewModal } from './components/WriteReviewModal';
import { ExpressCheckoutModal } from './components/ExpressCheckoutModal';
import { SearchModal } from './components/SearchModal';
import { WishlistDrawer } from './components/WishlistDrawer';
import { DropsCatalog } from './components/DropsCatalog';
import { LookbookModal } from './components/LookbookModal';
import { Footer } from './components/Footer';

export default function App() {
  const [currentView, setCurrentView] = useState<'home' | 'drops' | 'lookbook'>('home');
  const [currentProduct, setCurrentProduct] = useState<Product>(FLAGSHIP_PRODUCT);
  const [allProducts] = useState<Product[]>([FLAGSHIP_PRODUCT, ...RELATED_PRODUCTS]);
  const [reviews, setReviews] = useState<Review[]>(INITIAL_REVIEWS);

  // Initial cart items matching the "3" count badge in the original design screenshot
  const [cartItems, setCartItems] = useState<CartItem[]>([
    {
      productId: FLAGSHIP_PRODUCT.id,
      title: 'Men Printed V Neck Cotton Blend Purple T-Shirt (Gear 5 Awakened Edition)',
      price: FLAGSHIP_PRODUCT.price,
      image: GEAR_5_IMAGE,
      color: 'Purple',
      size: 'L',
      quantity: 1,
    },
    {
      productId: RELATED_PRODUCTS[0].id,
      title: RELATED_PRODUCTS[0].title,
      price: RELATED_PRODUCTS[0].price,
      image: RELATED_PRODUCTS[0].colors[0].images.front,
      color: 'Black',
      size: 'L',
      quantity: 1,
    },
    {
      productId: RELATED_PRODUCTS[2].id,
      title: RELATED_PRODUCTS[2].title,
      price: RELATED_PRODUCTS[2].price,
      image: RELATED_PRODUCTS[2].colors[0].images.front,
      color: 'Black',
      size: 'M',
      quantity: 1,
    },
  ]);

  const [wishlist, setWishlist] = useState<Product[]>([RELATED_PRODUCTS[1]]);
  const [appliedDiscount, setAppliedDiscount] = useState<number>(0);

  // Modal / Drawer visibility states
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isWishlistOpen, setIsWishlistOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);
  const [isSizeGuideOpen, setIsSizeGuideOpen] = useState(false);
  const [isWriteReviewOpen, setIsWriteReviewOpen] = useState(false);
  const [isExpressCheckoutOpen, setIsExpressCheckoutOpen] = useState(false);
  const [isLookbookOpen, setIsLookbookOpen] = useState(false);

  // Cart total items count
  const cartTotalCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // Add to cart handler
  const handleAddToCart = (
    product: Product,
    size: string,
    color: string,
    quantity: number
  ) => {
    const existingIndex = cartItems.findIndex(
      (item) => item.productId === product.id && item.size === size && item.color === color
    );

    const imageToUse =
      product.colors.find((c) => c.name.toLowerCase() === color.toLowerCase())?.images.front ||
      product.colors[0]?.images.front ||
      GEAR_5_IMAGE;

    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += quantity;
      setCartItems(updated);
    } else {
      setCartItems([
        ...cartItems,
        {
          productId: product.id,
          title: product.title,
          price: product.price,
          image: imageToUse,
          color,
          size,
          quantity,
        },
      ]);
    }
  };

  // Quick add (1 click default size L)
  const handleQuickAdd = (product: Product) => {
    handleAddToCart(product, 'L', product.colors[0]?.name || 'Purple', 1);
    setIsCartOpen(true);
  };

  // Express checkout trigger from PDP
  const handleExpressCheckout = (
    product: Product,
    size: string,
    color: string,
    quantity: number
  ) => {
    handleAddToCart(product, size, color, quantity);
    setIsExpressCheckoutOpen(true);
  };

  // Wishlist toggle
  const handleToggleWishlist = (product: Product) => {
    if (wishlist.some((p) => p.id === product.id)) {
      setWishlist(wishlist.filter((p) => p.id !== product.id));
    } else {
      setWishlist([...wishlist, product]);
    }
  };

  // Cart quantity updates
  const handleUpdateCartQuantity = (index: number, newQty: number) => {
    if (newQty <= 0) {
      handleRemoveCartItem(index);
    } else {
      const updated = [...cartItems];
      updated[index].quantity = newQty;
      setCartItems(updated);
    }
  };

  const handleRemoveCartItem = (index: number) => {
    setCartItems(cartItems.filter((_, idx) => idx !== index));
  };

  // Promo code validation
  const handleApplyPromoCode = (code: string): boolean => {
    if (code.toUpperCase() === 'GEAR5VIP' || code.toUpperCase() === 'AWAKENED') {
      setAppliedDiscount(10);
      return true;
    }
    return false;
  };

  // Review submission
  const handleAddReview = (newReview: Review) => {
    setReviews([newReview, ...reviews]);
  };

  // Smooth scroll to reviews
  const handleScrollToReviews = () => {
    const el = document.getElementById('reviews-section');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  // Select a product from related or catalog
  const handleSelectProduct = (product: Product) => {
    setCurrentProduct(product);
    setCurrentView('home');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-[#121414] text-[#e2e2e2] flex flex-col font-space selection:bg-[#7c03d3] selection:text-white">
      {/* Global Header */}
      <Header
        cartCount={cartTotalCount}
        wishlistCount={wishlist.length}
        currentView={currentView}
        onNavigate={(view) => {
          setCurrentView(view);
          if (view === 'lookbook') setIsLookbookOpen(true);
        }}
        onOpenCart={() => setIsCartOpen(true)}
        onOpenWishlist={() => setIsWishlistOpen(true)}
        onOpenSearch={() => setIsSearchOpen(true)}
      />

      {/* Main View Router */}
      <main className="flex-1 w-full">
        {currentView === 'home' && (
          <>
            {/* Primary Product Showcase (Gear 5 Awakened Edition) */}
            <ProductDetail
              product={currentProduct}
              onAddToCart={handleAddToCart}
              onExpressCheckout={handleExpressCheckout}
              onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
              onScrollToReviews={handleScrollToReviews}
              isWishlisted={wishlist.some((p) => p.id === currentProduct.id)}
              onToggleWishlist={handleToggleWishlist}
            />

            {/* Engineering & Craft Bento Grid ("Anatomy of the Awakening") */}
            <EngineeringSection product={currentProduct} />

            {/* Verified Customer Reviews Section */}
            <ReviewsSection
              reviews={reviews}
              onOpenWriteReview={() => setIsWriteReviewOpen(true)}
            />

            {/* Related Anime Streetwear Grid ("Complete the Drop") */}
            <RelatedProducts
              products={RELATED_PRODUCTS}
              onSelectProduct={handleSelectProduct}
              onQuickAdd={handleQuickAdd}
              onViewAllDrops={() => setCurrentView('drops')}
            />
          </>
        )}

        {currentView === 'drops' && (
          <DropsCatalog
            products={allProducts}
            onSelectProduct={handleSelectProduct}
            onQuickAdd={handleQuickAdd}
            onBackToMain={() => setCurrentView('home')}
          />
        )}
      </main>

      {/* Footer */}
      <Footer
        onOpenSizeGuide={() => setIsSizeGuideOpen(true)}
        onNavigateDrops={() => setCurrentView('drops')}
      />

      {/* Slide-over Shopping Bag / Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateCartQuantity}
        onRemoveItem={handleRemoveCartItem}
        onCheckout={() => {
          setIsCartOpen(false);
          setIsExpressCheckoutOpen(true);
        }}
        appliedDiscount={appliedDiscount}
        onApplyPromoCode={handleApplyPromoCode}
      />

      {/* Size Guide Modal */}
      <SizeGuideModal
        isOpen={isSizeGuideOpen}
        onClose={() => setIsSizeGuideOpen(false)}
      />

      {/* Write a Review Modal */}
      <WriteReviewModal
        isOpen={isWriteReviewOpen}
        onClose={() => setIsWriteReviewOpen(false)}
        onSubmitReview={handleAddReview}
      />

      {/* Express Checkout Modal */}
      <ExpressCheckoutModal
        isOpen={isExpressCheckoutOpen}
        onClose={() => setIsExpressCheckoutOpen(false)}
        items={cartItems}
        appliedDiscount={appliedDiscount}
        onOrderComplete={() => {
          setCartItems([]);
        }}
      />

      {/* Search Modal */}
      <SearchModal
        isOpen={isSearchOpen}
        onClose={() => setIsSearchOpen(false)}
        products={allProducts}
        onSelectProduct={handleSelectProduct}
      />

      {/* Wishlist Drawer */}
      <WishlistDrawer
        isOpen={isWishlistOpen}
        onClose={() => setIsWishlistOpen(false)}
        wishlist={wishlist}
        onRemoveWishlist={handleToggleWishlist}
        onAddToCart={(p) => {
          handleQuickAdd(p);
          setIsWishlistOpen(false);
        }}
        onSelectProduct={handleSelectProduct}
      />

      {/* Lookbook Modal */}
      <LookbookModal
        isOpen={isLookbookOpen}
        onClose={() => {
          setIsLookbookOpen(false);
          if (currentView === 'lookbook') setCurrentView('home');
        }}
        onShopDrop={() => {
          setIsLookbookOpen(false);
          setCurrentView('drops');
        }}
      />
    </div>
  );
}
