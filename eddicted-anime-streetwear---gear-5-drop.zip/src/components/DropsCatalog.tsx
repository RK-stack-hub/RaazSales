import React, { useState } from 'react';
import { Product } from '../types';

interface DropsCatalogProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onQuickAdd: (product: Product) => void;
  onBackToMain: () => void;
}

export const DropsCatalog: React.FC<DropsCatalogProps> = ({
  products,
  onSelectProduct,
  onQuickAdd,
  onBackToMain,
}) => {
  const [selectedSeries, setSelectedSeries] = useState<string>('All');
  const [sortBy, setSortBy] = useState<'hyped' | 'price-asc' | 'price-desc' | 'rating'>('hyped');

  const seriesOptions = ['All', 'Gear 5 Awakened', 'Three Sword Style', 'Diable Jambe', 'Ope Ope No Mi'];

  const filtered = products.filter((p) => {
    if (selectedSeries === 'All') return true;
    return p.series.toLowerCase().includes(selectedSeries.toLowerCase()) || p.title.toLowerCase().includes(selectedSeries.toLowerCase());
  });

  const sorted = [...filtered].sort((a, b) => {
    if (sortBy === 'price-asc') return a.price - b.price;
    if (sortBy === 'price-desc') return b.price - a.price;
    if (sortBy === 'rating') return b.rating - a.rating;
    return b.reviewCount - a.reviewCount;
  });

  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 text-[#e2e2e2] flex flex-col gap-8">
      {/* Top Banner & Return */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-4 pb-6 border-b border-[#282a2b]">
        <div>
          <button
            onClick={onBackToMain}
            className="text-xs text-[#ddb8ff] hover:text-white flex items-center gap-1 mb-2 font-semibold"
          >
            <span className="material-symbols-outlined text-[16px]">arrow_back</span>
            <span>Back to Gear 5 Flagship</span>
          </button>
          <span className="text-xs uppercase tracking-widest text-[#ddb8ff] font-bold">
            Full Archive &amp; Active Releases
          </span>
          <h1 className="font-anton text-4xl sm:text-5xl uppercase tracking-wide text-white mt-1">
            Streetwear Drops Catalog
          </h1>
        </div>

        {/* Sorting options */}
        <div className="flex items-center gap-2 text-xs">
          <span className="text-[#c9c5cc] uppercase tracking-wider font-semibold">Sort:</span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            className="bg-[#1a1c1c] border border-[#48464b] rounded-lg px-3 py-1.5 text-white focus:outline-none focus:border-[#7c03d3]"
          >
            <option value="hyped">Most Hyped</option>
            <option value="price-asc">Price: Low to High</option>
            <option value="price-desc">Price: High to Low</option>
            <option value="rating">Highest Rated</option>
          </select>
        </div>
      </div>

      {/* Series Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none">
        {seriesOptions.map((s) => (
          <button
            key={s}
            onClick={() => setSelectedSeries(s)}
            className={`px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-all border ${
              selectedSeries === s
                ? 'bg-[#7c03d3] border-[#ddb8ff] text-white shadow-[0_0_15px_rgba(124,3,211,0.5)]'
                : 'bg-[#1a1c1c] border-[#282a2b] text-[#c9c5cc] hover:border-[#48464b] hover:text-white'
            }`}
          >
            {s}
          </button>
        ))}
      </div>

      {/* Products Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {sorted.map((item) => {
          const img = item.colors[0]?.images.front;
          return (
            <div
              key={item.id}
              onClick={() => onSelectProduct(item)}
              className="bg-[#1a1c1c] rounded-xl overflow-hidden border border-[#282a2b] hover:border-[#7c03d3] transition-all cursor-pointer group flex flex-col shadow-lg"
            >
              <div className="relative aspect-[4/5] bg-[#333535] overflow-hidden">
                <img
                  src={img}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                {item.tag && (
                  <span className="absolute top-3 left-3 bg-[#121414]/90 px-2.5 py-1 rounded text-[10px] uppercase font-bold text-white border border-[#48464b]/40">
                    {item.tag}
                  </span>
                )}
                <div className="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onQuickAdd(item);
                    }}
                    className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shadow-lg flex items-center justify-center gap-1.5"
                  >
                    <span className="material-symbols-outlined text-[16px]">add_shopping_cart</span>
                    <span>Quick Add</span>
                  </button>
                </div>
              </div>

              <div className="p-5 flex flex-col gap-1.5 flex-1 justify-between">
                <div>
                  <span className="text-[10px] uppercase tracking-wider text-[#ddb8ff] font-bold">
                    {item.series}
                  </span>
                  <h3 className="font-anton text-lg text-white uppercase tracking-wide group-hover:text-[#ddb8ff] transition-colors mt-0.5 line-clamp-2">
                    {item.title}
                  </h3>
                </div>

                <div className="flex items-center justify-between pt-3 border-t border-[#282a2b] mt-2">
                  <span className="font-anton text-lg text-white">${item.price.toFixed(2)}</span>
                  <span className="text-xs text-[#c9c5cc] flex items-center gap-1">
                    <span>{item.rating}</span>
                    <span className="text-[#ddb8ff]">★</span>
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
