import React, { useState } from 'react';
import { Review } from '../types';

interface WriteReviewModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSubmitReview: (review: Review) => void;
}

export const WriteReviewModal: React.FC<WriteReviewModalProps> = ({
  isOpen,
  onClose,
  onSubmitReview,
}) => {
  const [rating, setRating] = useState(5);
  const [hoverRating, setHoverRating] = useState(0);
  const [name, setName] = useState('');
  const [size, setSize] = useState('Size L');
  const [color, setColor] = useState('Purple');
  const [fitVote, setFitVote] = useState<'runs-small' | 'true-to-size' | 'runs-large'>('true-to-size');
  const [comment, setComment] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!comment.trim() || !name.trim()) return;

    setIsSubmitting(true);
    setTimeout(() => {
      const initials = name
        .split(' ')
        .map((n) => n[0])
        .join('')
        .toUpperCase()
        .slice(0, 2) || 'ED';

      const newReview: Review = {
        id: `rev-${Date.now()}`,
        author: name.trim(),
        avatarInitials: initials,
        verified: true,
        size,
        color,
        date: 'Just now',
        rating,
        comment: comment.trim(),
        fitVote,
      };

      onSubmitReview(newReview);
      setIsSubmitting(false);
      onClose();
    }, 400);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#1a1c1c] border border-[#48464b] rounded-2xl max-w-lg w-full p-6 sm:p-8 flex flex-col gap-6 relative shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#c9c5cc] hover:text-white p-1 rounded-lg"
          aria-label="Close review modal"
        >
          <span className="material-symbols-outlined text-xl">close</span>
        </button>

        <div>
          <span className="text-xs uppercase tracking-wider text-[#ddb8ff] font-bold">
            Community Feedback
          </span>
          <h3 className="font-anton text-2xl uppercase text-white mt-1">
            Write a Verified Review
          </h3>
          <p className="text-xs text-[#c9c5cc] mt-0.5">
            Share your thoughts on the Gear 5 Awakened Edition tee with other fans.
          </p>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          {/* Star Rating Selector */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
              Overall Rating
            </label>
            <div className="flex items-center gap-1 text-[#ddb8ff]">
              {[1, 2, 3, 4, 5].map((star) => (
                <button
                  type="button"
                  key={star}
                  onMouseEnter={() => setHoverRating(star)}
                  onMouseLeave={() => setHoverRating(0)}
                  onClick={() => setRating(star)}
                  className="p-1 focus:outline-none hover:scale-110 transition-transform"
                >
                  <span
                    className="material-symbols-outlined text-2xl"
                    style={{
                      fontVariationSettings:
                        star <= (hoverRating || rating) ? "'FILL' 1" : "'FILL' 0",
                    }}
                  >
                    star
                  </span>
                </button>
              ))}
              <span className="text-xs text-[#c9c5cc] ml-2 font-semibold">
                {rating} out of 5 stars
              </span>
            </div>
          </div>

          {/* Name */}
          <div className="flex flex-col gap-1">
            <label className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
              Your Name / Alias
            </label>
            <input
              type="text"
              required
              placeholder="e.g. Kenji A. or StrawHatFan"
              value={name}
              onChange={(e) => setName(e.target.value)}
              className="bg-[#121414] border border-[#48464b] rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-[#7c03d3]"
            />
          </div>

          {/* Size & Color purchased */}
          <div className="grid grid-cols-2 gap-3">
            <div className="flex flex-col gap-1">
              <label className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
                Size Purchased
              </label>
              <select
                value={size}
                onChange={(e) => setSize(e.target.value)}
                className="bg-[#121414] border border-[#48464b] rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-[#7c03d3]"
              >
                <option value="Size S">Size S</option>
                <option value="Size M">Size M</option>
                <option value="Size L">Size L</option>
                <option value="Size XL">Size XL</option>
                <option value="Size XXL">Size XXL</option>
              </select>
            </div>
            <div className="flex flex-col gap-1">
              <label className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
                Color
              </label>
              <select
                value={color}
                onChange={(e) => setColor(e.target.value)}
                className="bg-[#121414] border border-[#48464b] rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-[#7c03d3]"
              >
                <option value="Purple">Purple</option>
                <option value="White">White</option>
                <option value="Black">Black</option>
              </select>
            </div>
          </div>

          {/* Fit Assessment */}
          <div className="flex flex-col gap-1.5">
            <label className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
              How does it fit?
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'runs-small', label: 'Runs Small' },
                { id: 'true-to-size', label: 'True to Size' },
                { id: 'runs-large', label: 'Runs Large' },
              ].map((opt) => (
                <button
                  type="button"
                  key={opt.id}
                  onClick={() => setFitVote(opt.id as any)}
                  className={`py-2 px-1 text-xs rounded border transition-colors ${
                    fitVote === opt.id
                      ? 'border-[#ddb8ff] bg-[#7c03d3]/20 text-[#ddb8ff] font-bold'
                      : 'border-[#48464b] bg-[#121414] text-[#c9c5cc]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Comment */}
          <div className="flex flex-col gap-1">
            <label className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
              Review Details
            </label>
            <textarea
              required
              rows={4}
              placeholder="How is the fabric weight, print fidelity, and collar ribbing? Does it hold up in the wash?"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="bg-[#121414] border border-[#48464b] rounded-lg p-2.5 text-sm text-white focus:outline-none focus:border-[#7c03d3] resize-none"
            />
          </div>

          <button
            type="submit"
            disabled={isSubmitting}
            className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] py-3 rounded-xl font-anton uppercase tracking-wider transition-colors shadow-lg mt-2 flex items-center justify-center gap-2"
          >
            {isSubmitting ? (
              <>
                <span className="material-symbols-outlined animate-spin text-lg">
                  progress_activity
                </span>
                <span>Publishing Review...</span>
              </>
            ) : (
              <span>Publish Verified Review</span>
            )}
          </button>
        </form>
      </div>
    </div>
  );
};
