import React, { useState } from 'react';
import { Product } from '../types';

interface SearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  onSelectProduct: (product: Product) => void;
}

export const SearchModal: React.FC<SearchModalProps> = ({
  isOpen,
  onClose,
  products,
  onSelectProduct,
}) => {
  const [query, setQuery] = useState('');

  if (!isOpen) return null;

  const popularTags = ['Gear 5', 'Zoro', 'Sanji', 'Law', 'Cotton V-Neck', 'Wano Arc'];

  const filtered = query.trim()
    ? products.filter(
        (p) =>
          p.title.toLowerCase().includes(query.toLowerCase()) ||
          p.series.toLowerCase().includes(query.toLowerCase()) ||
          p.description.toLowerCase().includes(query.toLowerCase())
      )
    : products;

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-start justify-center pt-20 p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#1a1c1c] border border-[#48464b] rounded-2xl max-w-2xl w-full p-6 flex flex-col gap-5 shadow-2xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 bg-[#121414] border border-[#48464b] rounded-xl px-4 py-3">
          <span className="material-symbols-outlined text-[#ddb8ff] text-2xl">search</span>
          <input
            type="text"
            autoFocus
            placeholder="Search anime streetwear drops (e.g. Gear 5, Zoro, Law)..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            className="flex-1 bg-transparent text-white text-base focus:outline-none placeholder-[#928f96]"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-[#928f96] hover:text-white"
            >
              <span className="material-symbols-outlined text-lg">cancel</span>
            </button>
          )}
          <button
            onClick={onClose}
            className="text-xs font-bold text-[#c9c5cc] hover:text-white px-2 py-1 bg-[#282a2b] rounded"
          >
            ESC
          </button>
        </div>

        {/* Hot search tags */}
        <div className="flex items-center gap-2 flex-wrap text-xs">
          <span className="text-[#928f96] uppercase tracking-wider font-semibold">Trending:</span>
          {popularTags.map((t) => (
            <button
              key={t}
              onClick={() => setQuery(t)}
              className="bg-[#121414] hover:bg-[#282a2b] text-[#ddb8ff] px-2.5 py-1 rounded-md border border-[#282a2b] transition-colors"
            >
              #{t}
            </button>
          ))}
        </div>

        {/* Search Results */}
        <div className="max-h-96 overflow-y-auto divide-y divide-[#282a2b] pr-1">
          {filtered.length === 0 ? (
            <div className="py-12 text-center text-[#c9c5cc]">
              <p className="text-sm">No anime streetwear drops found for "{query}".</p>
              <p className="text-xs text-[#928f96] mt-1">Try searching for Gear 5 or Katana.</p>
            </div>
          ) : (
            filtered.map((item) => (
              <div
                key={item.id}
                onClick={() => {
                  onSelectProduct(item);
                  onClose();
                }}
                className="py-3 px-2 flex items-center justify-between hover:bg-[#121414] rounded-lg transition-colors cursor-pointer group"
              >
                <div className="flex items-center gap-3">
                  <img
                    src={item.colors[0]?.images.front}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-12 h-12 object-cover rounded bg-[#282a2b]"
                  />
                  <div>
                    <h4 className="font-anton text-sm uppercase text-white group-hover:text-[#ddb8ff] transition-colors">
                      {item.title}
                    </h4>
                    <span className="text-xs text-[#c9c5cc]">{item.series}</span>
                  </div>
                </div>
                <div className="text-right">
                  <span className="font-anton text-sm text-white">${item.price.toFixed(2)}</span>
                  <span className="text-[11px] text-[#ddb8ff] block">
                    {item.stockLeft} in stock
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
