import React, { useState, useRef } from 'react';
import { Product } from '../types';

interface ProductDetailProps {
  product: Product;
  onAddToCart: (product: Product, size: string, color: string, quantity: number) => void;
  onExpressCheckout: (product: Product, size: string, color: string, quantity: number) => void;
  onOpenSizeGuide: () => void;
  onScrollToReviews: () => void;
  isWishlisted: boolean;
  onToggleWishlist: (product: Product) => void;
}

export const ProductDetail: React.FC<ProductDetailProps> = ({
  product,
  onAddToCart,
  onExpressCheckout,
  onOpenSizeGuide,
  onScrollToReviews,
  isWishlisted,
  onToggleWishlist,
}) => {
  const [selectedColor, setSelectedColor] = useState(product.colors[0]?.name || 'Purple');
  const [selectedSize, setSelectedSize] = useState('L');
  const [quantity, setQuantity] = useState(1);
  const [activeImageIndex, setActiveImageIndex] = useState(0);
  const [isAdding, setIsAdding] = useState(false);
  const [justAdded, setJustAdded] = useState(false);
  const [isZoomModalOpen, setIsZoomModalOpen] = useState(false);

  // Zoom lens effect states
  const [isHovered, setIsHovered] = useState(false);
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });
  const imageContainerRef = useRef<HTMLDivElement>(null);

  const activeColorObj =
    product.colors.find((c) => c.name.toLowerCase() === selectedColor.toLowerCase()) ||
    product.colors[0];

  const galleryImages = [
    {
      src: activeColorObj?.images.front || product.colors[0].images.front,
      title: 'Front View (Gear 5 Awakened Nika DTG)',
      alt: 'Close up front view of Eddicted Men Printed V Neck Cotton Blend Purple T-Shirt featuring Gear 5 Sun God Nika awakening design with vibrant purple and white accents.',
    },
    {
      src: activeColorObj?.images.back || product.colors[0].images.back,
      title: 'Back View (Mugiwara & Devil Fruit)',
      alt: 'Back view showcasing Mugiwara branding and devil fruit sleeve patch.',
    },
    {
      src: activeColorObj?.images.detail || product.colors[0].images.detail,
      title: 'Macro Detail (Collar Ribbing & DTG Inks)',
      alt: 'Detail shot of DTG print and ribbed V-neck collar.',
    },
    {
      src: activeColorObj?.images.lifestyle || product.colors[0].images.lifestyle,
      title: 'Streetwear Styling (Drop Shoulder Fit)',
      alt: 'Lifestyle view wearing the streetwear anime t-shirt.',
    },
  ];

  const currentImage = galleryImages[activeImageIndex] || galleryImages[0];

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!imageContainerRef.current) return;
    const rect = imageContainerRef.current.getBoundingClientRect();
    const x = ((e.clientX - rect.left) / rect.width) * 100;
    const y = ((e.clientY - rect.top) / rect.height) * 100;
    setMousePos({ x: Math.max(0, Math.min(100, x)), y: Math.max(0, Math.min(100, y)) });
  };

  const handleAdd = () => {
    setIsAdding(true);
    setTimeout(() => {
      setIsAdding(false);
      setJustAdded(true);
      onAddToCart(product, selectedSize, selectedColor, quantity);
      setTimeout(() => setJustAdded(false), 2400);
    }, 450);
  };

  return (
    <div className="w-full text-[#e2e2e2]">
      {/* Breadcrumb Navigation */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 w-full">
        <nav className="flex items-center gap-2 text-xs text-[#c9c5cc] overflow-x-auto whitespace-nowrap">
          <span className="hover:text-white transition-colors cursor-pointer">Home</span>
          <span className="material-symbols-outlined text-[14px]">chevron_right</span>
          <span className="hover:text-white transition-colors cursor-pointer">Men</span>
          <span className="material-symbols-outlined text-[14px]">chevron_right</span>
          <span className="hover:text-white transition-colors cursor-pointer">T-Shirts</span>
          <span className="material-symbols-outlined text-[14px]">chevron_right</span>
          <span className="hover:text-white transition-colors cursor-pointer">Anime Collection</span>
          <span className="material-symbols-outlined text-[14px]">chevron_right</span>
          <span className="text-white font-semibold">Gear 5 Tee</span>
        </nav>
      </div>

      {/* Main Product Showcase Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pb-16 w-full">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 lg:gap-12 items-start">
          {/* Left: Product Gallery (7 cols) */}
          <div className="lg:col-span-7 flex flex-col gap-4 lg:sticky lg:top-28">
            {/* Main Stage Image with Zoom effect */}
            <div
              ref={imageContainerRef}
              onMouseEnter={() => setIsHovered(true)}
              onMouseLeave={() => setIsHovered(false)}
              onMouseMove={handleMouseMove}
              onClick={() => setIsZoomModalOpen(true)}
              className="relative w-full aspect-square bg-[#1a1c1c] rounded-xl overflow-hidden group cursor-crosshair border border-[#282a2b] shadow-2xl"
            >
              <img
                src={currentImage.src}
                alt={currentImage.alt}
                id="main-product-image"
                referrerPolicy="no-referrer"
                style={{
                  transformOrigin: `${mousePos.x}% ${mousePos.y}%`,
                  transform: isHovered ? 'scale(1.85)' : 'scale(1)',
                }}
                className="w-full h-full object-cover transition-transform duration-200 ease-out will-change-transform"
              />

              {/* Tag Pill Badges */}
              <div className="absolute top-4 left-4 bg-[#7c03d3] text-[#dfbcff] px-3 py-1 rounded-full text-[11px] font-bold uppercase tracking-wider flex items-center gap-1 shadow-lg pointer-events-none">
                <span className="material-symbols-outlined text-[14px]">bolt</span>
                <span>Gear 5 Limited Drop</span>
              </div>

              {/* Wishlist toggle button */}
              <button
                onClick={(e) => {
                  e.stopPropagation();
                  onToggleWishlist(product);
                }}
                className="absolute top-4 right-4 bg-[#121414]/80 hover:bg-[#121414] backdrop-blur-md p-2.5 rounded-full text-white transition-transform active:scale-90 border border-[#48464b]"
                title={isWishlisted ? 'Remove from wishlist' : 'Save to wishlist'}
                aria-label="Toggle Wishlist"
              >
                <span
                  className={`material-symbols-outlined text-lg ${
                    isWishlisted ? 'text-[#ddb8ff]' : 'text-white'
                  }`}
                  style={{ fontVariationSettings: isWishlisted ? "'FILL' 1" : "'FILL' 0" }}
                >
                  favorite
                </span>
              </button>

              {/* Hover to Zoom tag */}
              <div className="absolute bottom-4 right-4 bg-[#121414]/85 backdrop-blur-md px-3 py-1.5 rounded-lg text-xs font-medium text-white flex items-center gap-1.5 border border-[#48464b]/40 pointer-events-none">
                <span className="material-symbols-outlined text-[16px]">zoom_in</span>
                <span>{isHovered ? 'Panning Detail' : 'Hover to Zoom / Click Full'}</span>
              </div>
            </div>

            {/* Thumbnail Selector */}
            <div className="grid grid-cols-4 gap-3 sm:gap-4">
              {galleryImages.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setActiveImageIndex(idx)}
                  className={`thumbnail-btn aspect-square bg-[#1a1c1c] rounded-lg overflow-hidden border-2 transition-all p-0.5 ${
                    activeImageIndex === idx
                      ? 'border-[#ddb8ff] ring-2 ring-[#7c03d3]/50 opacity-100 scale-102'
                      : 'border-transparent opacity-70 hover:opacity-100 hover:border-[#48464b]'
                  }`}
                  title={img.title}
                >
                  <img
                    src={img.src}
                    alt={img.alt}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover rounded"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Right: Product Details & Purchase Box (5 cols) */}
          <div className="lg:col-span-5 flex flex-col gap-6">
            {/* Brand Kicker & Title */}
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between">
                <span className="text-xs uppercase tracking-widest text-[#ddb8ff] font-bold">
                  {product.series}
                </span>
                <span className="bg-[#282a2b] text-[#c9c5cc] px-2 py-0.5 rounded text-[10px] uppercase font-mono tracking-wider">
                  SKU: {product.sku}
                </span>
              </div>
              <h1 className="font-anton text-3xl sm:text-4xl uppercase tracking-wide text-white leading-tight mt-1">
                {product.title}
              </h1>

              {/* Verified Rating & Reviews Link */}
              <div
                onClick={onScrollToReviews}
                className="flex items-center gap-2 mt-1 cursor-pointer hover:opacity-85 transition-opacity"
              >
                <div className="flex text-[#ddb8ff]">
                  {[...Array(5)].map((_, i) => (
                    <span
                      key={i}
                      className="material-symbols-outlined text-[18px]"
                      style={{ fontVariationSettings: "'FILL' 1" }}
                    >
                      star
                    </span>
                  ))}
                </div>
                <span className="text-xs font-semibold text-white">4.8 / 5.0</span>
                <span className="text-xs text-[#c9c5cc] underline underline-offset-2">
                  (1,240 verified reviews)
                </span>
              </div>
            </div>

            {/* Pricing Banner */}
            <div className="flex items-baseline gap-3 p-4 bg-[#1a1c1c] rounded-xl border border-[#282a2b]">
              <span className="font-anton text-3xl text-white tracking-wide">
                ${product.price.toFixed(2)}
              </span>
              <span className="text-base text-[#928f96] line-through font-medium">
                ${product.originalPrice.toFixed(2)}
              </span>
              <span className="bg-[#93000a] text-[#ffdad6] px-2 py-0.5 rounded text-xs uppercase font-bold tracking-wider">
                {product.discountPercent}% OFF
              </span>
              <span className="ml-auto text-[11px] text-[#c9c5cc] uppercase tracking-wider font-semibold">
                Tax Included
              </span>
            </div>

            {/* Color Selection */}
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <span className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
                  Color:{' '}
                  <span className="text-[#ddb8ff] font-bold capitalize">{selectedColor}</span>
                </span>
              </div>
              <div className="flex gap-3">
                {product.colors.map((c) => {
                  const isSelected = selectedColor.toLowerCase() === c.name.toLowerCase();
                  return (
                    <button
                      key={c.name}
                      onClick={() => setSelectedColor(c.name)}
                      className={`color-btn w-10 h-10 rounded-full transition-all flex items-center justify-center relative ${
                        isSelected
                          ? 'ring-2 ring-[#ddb8ff] ring-offset-2 ring-offset-[#121414] scale-105'
                          : 'border border-[#48464b] hover:scale-105'
                      }`}
                      style={{ backgroundColor: c.hex }}
                      title={`Select ${c.name}`}
                    >
                      {isSelected && (
                        <span className="material-symbols-outlined text-[18px] text-white font-bold drop-shadow">
                          check
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Size Selector */}
            <div className="flex flex-col gap-2">
              <div className="flex justify-between items-center">
                <span className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
                  Select Size
                </span>
                <button
                  onClick={onOpenSizeGuide}
                  className="text-xs text-[#ddb8ff] hover:text-white transition-colors flex items-center gap-1 underline underline-offset-2"
                >
                  <span className="material-symbols-outlined text-[15px]">straighten</span>
                  <span>Size Guide</span>
                </button>
              </div>

              <div className="grid grid-cols-5 gap-2">
                {product.sizes.map((s) => {
                  const isSelected = selectedSize === s;
                  return (
                    <button
                      key={s}
                      onClick={() => setSelectedSize(s)}
                      className={`size-btn py-2.5 rounded font-bold text-xs uppercase tracking-wider transition-all border ${
                        isSelected
                          ? 'border-[#ddb8ff] bg-[#7c03d3]/20 text-[#ddb8ff] ring-1 ring-[#ddb8ff]'
                          : 'bg-[#1e2020] border-[#48464b] hover:border-[#ddb8ff] text-white'
                      }`}
                    >
                      {s}
                    </button>
                  );
                })}
              </div>

              {/* Urgency Stock indicator */}
              <div className="flex items-center gap-1.5 text-xs text-[#ffb4ab] mt-1">
                <span className="material-symbols-outlined text-[16px] animate-pulse">
                  local_fire_department
                </span>
                <span>
                  In Stock — <strong>Only {product.stockLeft} items left</strong> in this size!
                </span>
              </div>
            </div>

            {/* Quantity Stepper */}
            <div className="flex items-center gap-4">
              <span className="text-xs uppercase tracking-wider text-[#e2e2e2] font-semibold">
                Quantity
              </span>
              <div className="flex items-center bg-[#1e2020] rounded-lg border border-[#48464b]">
                <button
                  onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                  className="px-3 py-1.5 text-[#c9c5cc] hover:text-white transition-colors"
                  aria-label="Decrease quantity"
                >
                  <span className="material-symbols-outlined text-[18px]">remove</span>
                </button>
                <span className="px-3 text-sm font-bold text-white min-w-8 text-center tabular-nums">
                  {quantity}
                </span>
                <button
                  onClick={() => setQuantity((q) => Math.min(10, q + 1))}
                  className="px-3 py-1.5 text-[#c9c5cc] hover:text-white transition-colors"
                  aria-label="Increase quantity"
                >
                  <span className="material-symbols-outlined text-[18px]">add</span>
                </button>
              </div>
            </div>

            {/* Primary Action CTAs */}
            <div className="flex flex-col gap-2.5 mt-2">
              <button
                onClick={handleAdd}
                disabled={isAdding}
                className={`w-full font-anton text-lg py-3.5 rounded-xl uppercase tracking-wider transition-all flex items-center justify-center gap-2 ${
                  justAdded
                    ? 'bg-emerald-600 text-white shadow-[0_0_25px_rgba(5,150,105,0.6)]'
                    : 'bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] shadow-[0_0_20px_rgba(124,3,211,0.4)] hover:shadow-[0_0_30px_rgba(221,184,255,0.6)]'
                }`}
              >
                {isAdding ? (
                  <>
                    <span className="material-symbols-outlined animate-spin text-xl">
                      progress_activity
                    </span>
                    <span>Adding to Cart...</span>
                  </>
                ) : justAdded ? (
                  <>
                    <span className="material-symbols-outlined text-xl">check</span>
                    <span>Added to Cart!</span>
                  </>
                ) : (
                  <>
                    <span className="material-symbols-outlined text-xl">shopping_bag</span>
                    <span>Add to Cart</span>
                  </>
                )}
              </button>

              <button
                onClick={() => onExpressCheckout(product, selectedSize, selectedColor, quantity)}
                className="w-full bg-[#333535] hover:bg-[#37393a] text-white font-anton text-lg py-3.5 rounded-xl uppercase tracking-wider transition-all border border-[#48464b] hover:border-white shadow-md flex items-center justify-center gap-2"
              >
                <span>Buy Now with Express Checkout</span>
              </button>
            </div>

            {/* Perks Grid */}
            <div className="grid grid-cols-3 gap-2 sm:gap-3 pt-4 border-t border-[#48464b]/60 mt-1">
              <div className="flex flex-col items-center text-center gap-1 p-2 sm:p-2.5 bg-[#1a1c1c] rounded-lg border border-[#282a2b]">
                <span className="material-symbols-outlined text-[#ddb8ff] text-xl">
                  local_shipping
                </span>
                <span className="text-[11px] leading-tight text-[#c9c5cc]">
                  Free Express Shipping on $50+
                </span>
              </div>
              <div className="flex flex-col items-center text-center gap-1 p-2 sm:p-2.5 bg-[#1a1c1c] rounded-lg border border-[#282a2b]">
                <span className="material-symbols-outlined text-[#ddb8ff] text-xl">
                  assignment_return
                </span>
                <span className="text-[11px] leading-tight text-[#c9c5cc]">
                  30-Day Easy Returns
                </span>
              </div>
              <div className="flex flex-col items-center text-center gap-1 p-2 sm:p-2.5 bg-[#1a1c1c] rounded-lg border border-[#282a2b]">
                <span className="material-symbols-outlined text-[#ddb8ff] text-xl">checkroom</span>
                <span className="text-[11px] leading-tight text-[#c9c5cc]">
                  100% Cotton Breathable Fabric
                </span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Fullscreen Lightbox Modal */}
      {isZoomModalOpen && (
        <div
          className="fixed inset-0 z-50 bg-black/95 flex items-center justify-center p-4 backdrop-blur-md"
          onClick={() => setIsZoomModalOpen(false)}
        >
          <button
            onClick={() => setIsZoomModalOpen(false)}
            className="absolute top-6 right-6 text-white hover:text-[#ddb8ff] p-2 bg-[#1e2020] rounded-full border border-[#48464b]"
            aria-label="Close image preview"
          >
            <span className="material-symbols-outlined text-2xl">close</span>
          </button>
          <div
            className="max-w-4xl max-h-[90vh] flex flex-col items-center gap-4"
            onClick={(e) => e.stopPropagation()}
          >
            <img
              src={currentImage.src}
              alt={currentImage.alt}
              referrerPolicy="no-referrer"
              className="max-h-[80vh] w-auto object-contain rounded-xl border border-[#48464b]"
            />
            <p className="text-sm font-semibold text-[#ddb8ff] uppercase tracking-wider">
              {currentImage.title}
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
