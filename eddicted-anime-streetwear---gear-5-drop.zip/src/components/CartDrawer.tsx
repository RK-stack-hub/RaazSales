import React, { useState } from 'react';
import { CartItem } from '../types';

interface CartDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onUpdateQuantity: (index: number, newQty: number) => void;
  onRemoveItem: (index: number) => void;
  onCheckout: () => void;
  appliedDiscount: number;
  onApplyPromoCode: (code: string) => boolean;
}

export const CartDrawer: React.FC<CartDrawerProps> = ({
  isOpen,
  onClose,
  items,
  onUpdateQuantity,
  onRemoveItem,
  onCheckout,
  appliedDiscount,
  onApplyPromoCode,
}) => {
  const [promoInput, setPromoInput] = useState('');
  const [promoMessage, setPromoMessage] = useState<{ text: string; error: boolean } | null>(null);

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discountAmount = subtotal * (appliedDiscount / 100);
  const discountedSubtotal = subtotal - discountAmount;
  // Free shipping threshold is $50
  const freeShippingThreshold = 50.0;
  const shipping = subtotal >= freeShippingThreshold || items.length === 0 ? 0 : 9.99;
  const total = discountedSubtotal + shipping;

  const handleApplyPromo = (e: React.FormEvent) => {
    e.preventDefault();
    if (!promoInput.trim()) return;
    const success = onApplyPromoCode(promoInput.trim());
    if (success) {
      setPromoMessage({ text: 'Code GEAR5VIP applied! 10% extra off.', error: false });
    } else {
      setPromoMessage({ text: 'Invalid promo code. Try GEAR5VIP.', error: true });
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      {/* Backdrop */}
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#1a1c1c] border-l border-[#282a2b] shadow-2xl flex flex-col justify-between text-[#e2e2e2]">
          {/* Header */}
          <div className="p-6 border-b border-[#282a2b] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#ddb8ff]">shopping_bag</span>
              <h2 className="font-anton text-2xl uppercase tracking-wider text-white">
                Shopping Bag ({items.reduce((s, i) => s + i.quantity, 0)})
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-[#c9c5cc] hover:text-white"
              aria-label="Close cart"
            >
              <span className="material-symbols-outlined text-xl">close</span>
            </button>
          </div>

          {/* Free Shipping Progress */}
          <div className="bg-[#121414] px-6 py-3 border-b border-[#282a2b] text-xs">
            {subtotal >= freeShippingThreshold ? (
              <div className="flex items-center gap-2 text-emerald-400 font-semibold">
                <span className="material-symbols-outlined text-base">check_circle</span>
                <span>You unlocked Free Worldwide Express Shipping!</span>
              </div>
            ) : (
              <div className="flex flex-col gap-1.5">
                <div className="flex justify-between text-[#c9c5cc]">
                  <span>Free Express Shipping at ${freeShippingThreshold}</span>
                  <span className="text-[#ddb8ff] font-bold">
                    ${(freeShippingThreshold - subtotal).toFixed(2)} away
                  </span>
                </div>
                <div className="w-full h-1.5 bg-[#282a2b] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#7c03d3] rounded-full transition-all duration-300"
                    style={{ width: `${Math.min(100, (subtotal / freeShippingThreshold) * 100)}%` }}
                  ></div>
                </div>
              </div>
            )}
          </div>

          {/* Items List */}
          <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4">
            {items.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center gap-3 py-16">
                <span className="material-symbols-outlined text-5xl text-[#48464b]">
                  shopping_cart_off
                </span>
                <p className="font-anton text-xl uppercase text-white">Your bag is empty</p>
                <p className="text-xs text-[#c9c5cc] max-w-xs">
                  Gear 5 Awakened Edition and pirate streetwear drops are moving fast.
                </p>
                <button
                  onClick={onClose}
                  className="bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] px-5 py-2.5 rounded-lg text-xs font-anton uppercase tracking-wider transition-colors mt-2"
                >
                  Explore Drops
                </button>
              </div>
            ) : (
              items.map((item, idx) => (
                <div
                  key={`${item.productId}-${item.size}-${item.color}-${idx}`}
                  className="bg-[#121414] p-3 rounded-xl border border-[#282a2b] flex gap-3 items-center"
                >
                  <img
                    src={item.image}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    className="w-18 h-18 object-cover rounded-lg bg-[#1e2020] border border-[#282a2b]"
                  />
                  <div className="flex-1 min-w-0">
                    <h4 className="font-anton text-sm text-white truncate uppercase">
                      {item.title}
                    </h4>
                    <p className="text-[11px] text-[#c9c5cc] mt-0.5">
                      Size: <strong className="text-white">{item.size}</strong> • Color:{' '}
                      <strong className="text-white">{item.color}</strong>
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <div className="flex items-center bg-[#1a1c1c] rounded border border-[#48464b]">
                        <button
                          onClick={() => onUpdateQuantity(idx, item.quantity - 1)}
                          className="px-2 py-0.5 text-xs text-[#c9c5cc] hover:text-white"
                        >
                          -
                        </button>
                        <span className="px-2 text-xs font-bold text-white tabular-nums">
                          {item.quantity}
                        </span>
                        <button
                          onClick={() => onUpdateQuantity(idx, item.quantity + 1)}
                          className="px-2 py-0.5 text-xs text-[#c9c5cc] hover:text-white"
                        >
                          +
                        </button>
                      </div>
                      <span className="font-anton text-sm text-white">
                        ${(item.price * item.quantity).toFixed(2)}
                      </span>
                    </div>
                  </div>
                  <button
                    onClick={() => onRemoveItem(idx)}
                    className="text-[#928f96] hover:text-[#ffb4ab] p-1.5 transition-colors self-start"
                    title="Remove item"
                  >
                    <span className="material-symbols-outlined text-lg">delete</span>
                  </button>
                </div>
              ))
            )}
          </div>

          {/* Footer & Checkout Box */}
          {items.length > 0 && (
            <div className="p-6 bg-[#121414] border-t border-[#282a2b] flex flex-col gap-4">
              {/* Promo Code Form */}
              <form onSubmit={handleApplyPromo} className="flex gap-2">
                <input
                  type="text"
                  placeholder="Promo Code (Try: GEAR5VIP)"
                  value={promoInput}
                  onChange={(e) => setPromoInput(e.target.value)}
                  className="flex-1 bg-[#1a1c1c] border border-[#48464b] rounded-lg px-3 py-2 text-xs text-white uppercase focus:outline-none focus:border-[#7c03d3]"
                />
                <button
                  type="submit"
                  className="bg-[#282a2b] hover:bg-[#333535] text-[#ddb8ff] px-4 py-2 rounded-lg text-xs font-bold uppercase transition-colors"
                >
                  Apply
                </button>
              </form>
              {promoMessage && (
                <p
                  className={`text-xs ${
                    promoMessage.error ? 'text-[#ffb4ab]' : 'text-emerald-400'
                  }`}
                >
                  {promoMessage.text}
                </p>
              )}

              {/* Price Calculations */}
              <div className="flex flex-col gap-1.5 text-xs text-[#c9c5cc] pt-2 border-t border-[#282a2b]">
                <div className="flex justify-between">
                  <span>Subtotal</span>
                  <span className="font-mono text-white">${subtotal.toFixed(2)}</span>
                </div>
                {appliedDiscount > 0 && (
                  <div className="flex justify-between text-emerald-400">
                    <span>VIP Discount ({appliedDiscount}%)</span>
                    <span className="font-mono">-${discountAmount.toFixed(2)}</span>
                  </div>
                )}
                <div className="flex justify-between">
                  <span>Express Shipping</span>
                  <span className="font-mono text-white">
                    {shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span>Sales Tax</span>
                  <span className="text-[11px] text-[#928f96]">Included</span>
                </div>
                <div className="flex justify-between text-sm font-bold text-white pt-2 border-t border-[#282a2b]">
                  <span>Total</span>
                  <span className="font-anton text-lg text-[#ddb8ff]">${total.toFixed(2)}</span>
                </div>
              </div>

              {/* Checkout Button */}
              <button
                onClick={onCheckout}
                className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] py-3.5 rounded-xl font-anton text-base uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(124,3,211,0.4)] flex items-center justify-center gap-2"
              >
                <span className="material-symbols-outlined text-lg">bolt</span>
                <span>Proceed to Express Checkout</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
