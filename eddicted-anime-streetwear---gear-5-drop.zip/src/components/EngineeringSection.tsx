import React, { useState } from 'react';
import { Product } from '../types';

interface EngineeringSectionProps {
  product: Product;
}

export const EngineeringSection: React.FC<EngineeringSectionProps> = ({ product }) => {
  const [showSpecsModal, setShowSpecsModal] = useState(false);

  return (
    <section className="w-full bg-[#1a1c1c] py-16 border-y border-[#282a2b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col gap-12">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#ddb8ff] font-bold">
              Engineering &amp; Craft
            </span>
            <h2 className="font-anton text-3xl sm:text-4xl md:text-5xl uppercase tracking-wide text-white mt-1">
              Anatomy of the Awakening
            </h2>
          </div>
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
            <p className="text-sm md:text-base text-[#c9c5cc] max-w-md">
              Every thread is meticulously engineered to withstand high-intensity wear while honoring
              legendary Japanese streetwear culture.
            </p>
            <button
              onClick={() => setShowSpecsModal(true)}
              className="bg-[#1e2020] hover:bg-[#282a2b] text-[#ddb8ff] border border-[#48464b] px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-wider whitespace-nowrap transition-colors flex items-center gap-1.5"
            >
              <span className="material-symbols-outlined text-[16px]">tune</span>
              <span>Tech Spec Sheet</span>
            </button>
          </div>
        </div>

        {/* Bento Grid Features */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {product.features.map((feature, idx) => (
            <div
              key={idx}
              className="bg-[#121414] p-8 rounded-xl flex flex-col gap-4 relative overflow-hidden group border border-[#282a2b] hover:border-[#7c03d3]/60 transition-all shadow-md hover:shadow-[0_0_25px_rgba(124,3,211,0.15)]"
            >
              {/* Subtle ambient glowing background orb */}
              <div className="absolute top-0 right-0 w-36 h-36 bg-[#7c03d3]/5 rounded-full blur-2xl group-hover:bg-[#7c03d3]/15 transition-all"></div>

              <div className="w-12 h-12 rounded-lg bg-[#7c03d3] text-[#dfbcff] flex items-center justify-center shrink-0 shadow-lg">
                <span className="material-symbols-outlined text-2xl">{feature.icon}</span>
              </div>

              <h3 className="font-anton text-2xl uppercase text-white tracking-wide">
                {feature.title}
              </h3>

              <p className="text-sm text-[#c9c5cc] leading-relaxed relative z-10">{feature.desc}</p>
            </div>
          ))}
        </div>
      </div>

      {/* Tech Spec Sheet Modal */}
      {showSpecsModal && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-md flex items-center justify-center p-4"
          onClick={() => setShowSpecsModal(false)}
        >
          <div
            className="bg-[#1a1c1c] border border-[#48464b] rounded-2xl max-w-lg w-full p-6 sm:p-8 flex flex-col gap-6 relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setShowSpecsModal(false)}
              className="absolute top-4 right-4 text-[#c9c5cc] hover:text-white p-1 rounded-lg"
              aria-label="Close modal"
            >
              <span className="material-symbols-outlined text-xl">close</span>
            </button>

            <div>
              <span className="text-xs uppercase tracking-wider text-[#ddb8ff] font-bold">
                Garment Blueprint
              </span>
              <h3 className="font-anton text-2xl uppercase text-white mt-1">
                Technical Specifications
              </h3>
            </div>

            <div className="divide-y divide-[#282a2b] text-sm">
              <div className="py-2.5 flex justify-between">
                <span className="text-[#c9c5cc]">Fabric Composition</span>
                <span className="font-semibold text-white text-right">
                  {product.specifications.material}
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#c9c5cc]">Fabric Weight</span>
                <span className="font-semibold text-white text-right">
                  {product.specifications.weight}
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#c9c5cc]">Cut &amp; Silhouette</span>
                <span className="font-semibold text-white text-right">
                  {product.specifications.fit}
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#c9c5cc]">Print Technology</span>
                <span className="font-semibold text-white text-right">
                  Direct-to-Garment (DTG) 1200 DPI
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#c9c5cc]">Care Instructions</span>
                <span className="font-semibold text-white text-right">
                  {product.specifications.care}
                </span>
              </div>
              <div className="py-2.5 flex justify-between">
                <span className="text-[#c9c5cc]">Official Certification</span>
                <span className="font-semibold text-[#ddb8ff] text-right">
                  {product.specifications.origin}
                </span>
              </div>
            </div>

            <button
              onClick={() => setShowSpecsModal(false)}
              className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] py-2.5 rounded-lg font-anton uppercase tracking-wider transition-colors"
            >
              Close Blueprint
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
