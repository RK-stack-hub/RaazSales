import React, { useState } from 'react';

interface SizeGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const SizeGuideModal: React.FC<SizeGuideModalProps> = ({ isOpen, onClose }) => {
  const [unit, setUnit] = useState<'inches' | 'cm'>('inches');
  const [heightVal, setHeightVal] = useState('175');
  const [weightVal, setWeightVal] = useState('72');
  const [recommendedSize, setRecommendedSize] = useState<string | null>(null);

  if (!isOpen) return null;

  const handleCalculate = (e: React.FormEvent) => {
    e.preventDefault();
    const h = parseInt(heightVal) || 175;
    const w = parseInt(weightVal) || 70;
    if (w < 60) setRecommendedSize('S');
    else if (w < 72) setRecommendedSize('M');
    else if (w < 82) setRecommendedSize('L');
    else if (w < 92) setRecommendedSize('XL');
    else setRecommendedSize('XXL');
  };

  const rows =
    unit === 'inches'
      ? [
          { size: 'S', chest: '38-40"', length: '28"', shoulder: '18"' },
          { size: 'M', chest: '40-42"', length: '29"', shoulder: '19"' },
          { size: 'L', chest: '42-44"', length: '30"', shoulder: '20"' },
          { size: 'XL', chest: '44-46"', length: '31"', shoulder: '21"' },
          { size: 'XXL', chest: '46-48"', length: '32"', shoulder: '22"' },
        ]
      : [
          { size: 'S', chest: '96-101 cm', length: '71 cm', shoulder: '46 cm' },
          { size: 'M', chest: '101-106 cm', length: '74 cm', shoulder: '48 cm' },
          { size: 'L', chest: '106-112 cm', length: '76 cm', shoulder: '51 cm' },
          { size: 'XL', chest: '112-117 cm', length: '79 cm', shoulder: '53 cm' },
          { size: 'XXL', chest: '117-122 cm', length: '81 cm', shoulder: '56 cm' },
        ];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#1a1c1c] border border-[#48464b] rounded-2xl max-w-lg w-full p-6 sm:p-8 flex flex-col gap-6 relative shadow-2xl max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#c9c5cc] hover:text-white p-1 rounded-lg"
          aria-label="Close size guide"
        >
          <span className="material-symbols-outlined text-xl">close</span>
        </button>

        <div className="flex justify-between items-start">
          <div>
            <span className="text-xs uppercase tracking-wider text-[#ddb8ff] font-bold">
              Fit Matrix
            </span>
            <h3 className="font-anton text-2xl uppercase text-white mt-1">
              Size Guide ({unit.toUpperCase()})
            </h3>
          </div>

          {/* Unit Toggle */}
          <div className="flex items-center bg-[#121414] rounded-lg p-1 border border-[#282a2b] mr-6">
            <button
              onClick={() => setUnit('inches')}
              className={`px-2.5 py-1 text-xs font-bold rounded ${
                unit === 'inches' ? 'bg-[#7c03d3] text-white' : 'text-[#c9c5cc]'
              }`}
            >
              Inches
            </button>
            <button
              onClick={() => setUnit('cm')}
              className={`px-2.5 py-1 text-xs font-bold rounded ${
                unit === 'cm' ? 'bg-[#7c03d3] text-white' : 'text-[#c9c5cc]'
              }`}
            >
              CM
            </button>
          </div>
        </div>

        {/* Size Table */}
        <div className="overflow-x-auto rounded-lg border border-[#282a2b]">
          <table className="w-full text-left text-sm text-[#c9c5cc]">
            <thead className="text-[11px] uppercase bg-[#1e2020] text-white tracking-wider">
              <tr>
                <th className="p-3">Size</th>
                <th className="p-3">Chest</th>
                <th className="p-3">Length</th>
                <th className="p-3">Shoulder</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#282a2b]">
              {rows.map((r) => (
                <tr key={r.size} className="hover:bg-[#121414] transition-colors">
                  <td className="p-3 font-bold text-white">{r.size}</td>
                  <td className="p-3">{r.chest}</td>
                  <td className="p-3">{r.length}</td>
                  <td className="p-3">{r.shoulder}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Smart Fit Predictor */}
        <div className="bg-[#121414] p-4 rounded-xl border border-[#282a2b] flex flex-col gap-3">
          <div className="flex items-center gap-2">
            <span className="material-symbols-outlined text-[#ddb8ff] text-base">straighten</span>
            <span className="text-xs uppercase font-bold text-white tracking-wider">
              Find Your Streetwear Fit
            </span>
          </div>
          <form onSubmit={handleCalculate} className="grid grid-cols-2 gap-3 text-xs">
            <div>
              <label className="text-[#c9c5cc] block mb-1">Height (cm)</label>
              <input
                type="number"
                value={heightVal}
                onChange={(e) => setHeightVal(e.target.value)}
                className="w-full bg-[#1a1c1c] border border-[#48464b] rounded p-2 text-white focus:outline-none focus:border-[#7c03d3]"
              />
            </div>
            <div>
              <label className="text-[#c9c5cc] block mb-1">Weight (kg)</label>
              <input
                type="number"
                value={weightVal}
                onChange={(e) => setWeightVal(e.target.value)}
                className="w-full bg-[#1a1c1c] border border-[#48464b] rounded p-2 text-white focus:outline-none focus:border-[#7c03d3]"
              />
            </div>
            <button
              type="submit"
              className="col-span-2 bg-[#282a2b] hover:bg-[#333535] text-[#ddb8ff] font-bold py-2 rounded text-xs uppercase tracking-wider transition-colors"
            >
              Recommend My Size
            </button>
          </form>

          {recommendedSize && (
            <div className="bg-[#7c03d3]/20 border border-[#ddb8ff]/40 p-2.5 rounded-lg text-center animate-in fade-in">
              <span className="text-xs text-[#c9c5cc]">Recommended Streetwear Fit: </span>
              <strong className="text-sm text-white font-bold">Size {recommendedSize}</strong>
              <span className="text-[11px] text-[#ddb8ff] block mt-0.5">
                (Slightly relaxed Tokyo box fit)
              </span>
            </div>
          )}
        </div>

        <button
          onClick={onClose}
          className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] py-3 rounded-xl font-anton uppercase tracking-wider transition-colors"
        >
          Got It
        </button>
      </div>
    </div>
  );
};
