import React from 'react';
import { GEAR_5_IMAGE, ZORO_IMAGE, SANJI_IMAGE, LAW_IMAGE } from '../data/products';

interface LookbookModalProps {
  isOpen: boolean;
  onClose: () => void;
  onShopDrop: () => void;
}

export const LookbookModal: React.FC<LookbookModalProps> = ({ isOpen, onClose, onShopDrop }) => {
  if (!isOpen) return null;

  const outfits = [
    {
      title: 'Sun God Awakening in Shinjuku',
      piece: 'Gear 5 V-Neck Tee in Royal Purple',
      pairing: 'Styled with matte black cargo trousers and distressed combat boots',
      image: GEAR_5_IMAGE,
      tag: 'AW/26 Drop 01',
    },
    {
      title: 'Santoryu Midnight Techwear',
      piece: 'Zoro Katana Slash Boxy Tee',
      pairing: 'Layered over white waffle thermal with tactical utility chest rig',
      image: ZORO_IMAGE,
      tag: 'AW/26 Drop 02',
    },
    {
      title: 'Diable Jambe Fiery Halftone',
      piece: 'Sanji Flame Kick Vintage Tee',
      pairing: 'Paired with raw selvedge denim and oversized work jacket',
      image: SANJI_IMAGE,
      tag: 'AW/26 Drop 03',
    },
    {
      title: 'Surgeon of Death Minimalist Room',
      piece: 'Law Room Tech Tee',
      pairing: 'Styled with tech fleece track pants and Heart Pirates woven bucket hat',
      image: LAW_IMAGE,
      tag: 'AW/26 Drop 04',
    },
  ];

  return (
    <div
      className="fixed inset-0 z-50 bg-black/95 backdrop-blur-md flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#1a1c1c] border border-[#48464b] rounded-2xl max-w-4xl w-full p-6 sm:p-8 flex flex-col gap-6 relative shadow-2xl max-h-[92vh] overflow-y-auto text-[#e2e2e2]"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#c9c5cc] hover:text-white p-1 rounded-lg"
          aria-label="Close lookbook"
        >
          <span className="material-symbols-outlined text-xl">close</span>
        </button>

        <div>
          <span className="text-xs uppercase tracking-widest text-[#ddb8ff] font-bold">
            Editorial Lookbook • Autumn/Winter 2026
          </span>
          <h2 className="font-anton text-3xl sm:text-4xl uppercase tracking-wide text-white mt-1">
            Rebellious Anime Subculture
          </h2>
          <p className="text-xs sm:text-sm text-[#c9c5cc] mt-1 max-w-xl">
            Shot on location across Tokyo and Osaka. Heavyweight knit draping, raw direct-to-garment
            tactility, and futuristic Japanese street silhouettes.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
          {outfits.map((look, idx) => (
            <div
              key={idx}
              className="bg-[#121414] rounded-xl overflow-hidden border border-[#282a2b] flex flex-col group hover:border-[#7c03d3] transition-all shadow-lg"
            >
              <div className="relative aspect-[4/5] overflow-hidden bg-[#282a2b]">
                <img
                  src={look.image}
                  alt={look.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <span className="absolute top-3 left-3 bg-[#121414]/90 px-2.5 py-1 rounded text-[10px] font-bold text-white uppercase tracking-wider border border-[#48464b]/40">
                  {look.tag}
                </span>
              </div>
              <div className="p-4 flex flex-col gap-1">
                <h4 className="font-anton text-lg uppercase text-white tracking-wide">
                  {look.title}
                </h4>
                <p className="text-xs text-[#ddb8ff] font-semibold">{look.piece}</p>
                <p className="text-xs text-[#c9c5cc] mt-0.5">{look.pairing}</p>
              </div>
            </div>
          ))}
        </div>

        <div className="flex justify-between items-center pt-4 border-t border-[#282a2b]">
          <span className="text-xs text-[#c9c5cc]">All pieces officially licensed &amp; printed in limited runs.</span>
          <button
            onClick={() => {
              onClose();
              onShopDrop();
            }}
            className="bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] px-5 py-2.5 rounded-lg text-xs font-anton uppercase tracking-wider transition-colors"
          >
            Shop the Looks
          </button>
        </div>
      </div>
    </div>
  );
};
