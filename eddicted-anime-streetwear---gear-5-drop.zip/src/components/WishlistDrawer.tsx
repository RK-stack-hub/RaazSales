import React from 'react';
import { Product } from '../types';

interface WishlistDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  wishlist: Product[];
  onRemoveWishlist: (product: Product) => void;
  onAddToCart: (product: Product) => void;
  onSelectProduct: (product: Product) => void;
}

export const WishlistDrawer: React.FC<WishlistDrawerProps> = ({
  isOpen,
  onClose,
  wishlist,
  onRemoveWishlist,
  onAddToCart,
  onSelectProduct,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden">
      <div
        className="absolute inset-0 bg-black/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      />

      <div className="fixed inset-y-0 right-0 max-w-full flex pl-10">
        <div className="w-screen max-w-md bg-[#1a1c1c] border-l border-[#282a2b] shadow-2xl flex flex-col justify-between text-[#e2e2e2]">
          <div className="p-6 border-b border-[#282a2b] flex items-center justify-between">
            <div className="flex items-center gap-2">
              <span className="material-symbols-outlined text-[#ddb8ff]">favorite</span>
              <h2 className="font-anton text-2xl uppercase tracking-wider text-white">
                Saved Grails ({wishlist.length})
              </h2>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-[#c9c5cc] hover:text-white"
              aria-label="Close wishlist"
            >
              <span className="material-symbols-outlined text-xl">close</span>
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-6 flex flex-col gap-4">
            {wishlist.length === 0 ? (
              <div className="flex-1 flex flex-col items-center justify-center text-center gap-3 py-16">
                <span className="material-symbols-outlined text-5xl text-[#48464b]">
                  heart_broken
                </span>
                <p className="font-anton text-xl uppercase text-white">No items saved yet</p>
                <p className="text-xs text-[#c9c5cc] max-w-xs">
                  Tap the heart icon on any anime tee or drop to track limited releases.
                </p>
              </div>
            ) : (
              wishlist.map((item) => (
                <div
                  key={item.id}
                  className="bg-[#121414] p-3 rounded-xl border border-[#282a2b] flex gap-3 items-center"
                >
                  <img
                    src={item.colors[0]?.images.front}
                    alt={item.title}
                    referrerPolicy="no-referrer"
                    onClick={() => {
                      onSelectProduct(item);
                      onClose();
                    }}
                    className="w-18 h-18 object-cover rounded-lg bg-[#1e2020] border border-[#282a2b] cursor-pointer"
                  />
                  <div className="flex-1 min-w-0">
                    <h4
                      onClick={() => {
                        onSelectProduct(item);
                        onClose();
                      }}
                      className="font-anton text-sm text-white truncate uppercase cursor-pointer hover:text-[#ddb8ff]"
                    >
                      {item.title}
                    </h4>
                    <p className="text-xs text-[#c9c5cc]">{item.series}</p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="font-anton text-sm text-white">
                        ${item.price.toFixed(2)}
                      </span>
                      <button
                        onClick={() => onAddToCart(item)}
                        className="bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] px-3 py-1 rounded text-xs font-bold uppercase transition-colors"
                      >
                        Add to Bag
                      </button>
                    </div>
                  </div>
                  <button
                    onClick={() => onRemoveWishlist(item)}
                    className="text-[#928f96] hover:text-[#ffb4ab] p-1.5 self-start"
                    title="Remove from wishlist"
                  >
                    <span className="material-symbols-outlined text-lg">close</span>
                  </button>
                </div>
              ))
            )}
          </div>

          <div className="p-6 bg-[#121414] border-t border-[#282a2b]">
            <button
              onClick={onClose}
              className="w-full bg-[#282a2b] hover:bg-[#333535] text-white py-3 rounded-xl font-anton uppercase tracking-wider transition-colors"
            >
              Continue Browsing
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
