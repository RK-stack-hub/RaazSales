import React from 'react';
import { Product } from '../types';

interface RelatedProductsProps {
  products: Product[];
  onSelectProduct: (product: Product) => void;
  onQuickAdd: (product: Product) => void;
  onViewAllDrops: () => void;
}

export const RelatedProducts: React.FC<RelatedProductsProps> = ({
  products,
  onSelectProduct,
  onQuickAdd,
  onViewAllDrops,
}) => {
  return (
    <section className="w-full bg-[#1a1c1c] py-16 border-t border-[#282a2b]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col gap-10">
        <div className="flex justify-between items-end">
          <div>
            <span className="text-xs uppercase tracking-widest text-[#ddb8ff] font-bold">
              Complete the Drop
            </span>
            <h2 className="font-anton text-3xl sm:text-4xl md:text-5xl uppercase tracking-wide text-white mt-1">
              Related Anime Streetwear
            </h2>
          </div>
          <button
            onClick={onViewAllDrops}
            className="hidden md:flex items-center gap-1.5 text-sm text-[#ddb8ff] hover:text-white font-semibold transition-colors group"
          >
            <span>View All Drops</span>
            <span className="material-symbols-outlined text-[18px] group-hover:translate-x-1 transition-transform">
              arrow_forward
            </span>
          </button>
        </div>

        {/* Products Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {products.map((p) => {
            const mainImg = p.colors[0]?.images.front || '';
            return (
              <div
                key={p.id}
                onClick={() => onSelectProduct(p)}
                className="bg-[#121414] rounded-xl overflow-hidden group flex flex-col border border-[#282a2b] hover:border-[#7c03d3]/80 transition-all cursor-pointer shadow-lg hover:shadow-[0_0_25px_rgba(124,3,211,0.2)]"
              >
                {/* Image Container with Tag */}
                <div className="relative aspect-[4/5] bg-[#333535] overflow-hidden">
                  <img
                    src={mainImg}
                    alt={p.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  />
                  {p.tag && (
                    <div className="absolute top-3 left-3 bg-[#121414]/85 backdrop-blur-md px-2.5 py-1 rounded text-[11px] font-bold uppercase tracking-wider text-white border border-[#48464b]/40">
                      {p.tag}
                    </div>
                  )}

                  {/* Quick Add Overlay on hover */}
                  <div className="absolute inset-x-3 bottom-3 opacity-0 group-hover:opacity-100 transition-opacity">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onQuickAdd(p);
                      }}
                      className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] py-2 rounded-lg text-xs font-bold uppercase tracking-wider transition-colors shadow-lg flex items-center justify-center gap-1.5"
                    >
                      <span className="material-symbols-outlined text-[16px]">add_shopping_cart</span>
                      <span>Quick Add to Bag</span>
                    </button>
                  </div>
                </div>

                {/* Info */}
                <div className="p-6 flex flex-col gap-1.5 flex-1 justify-between">
                  <div>
                    <span className="text-[11px] uppercase tracking-wider text-[#ddb8ff] font-bold">
                      {p.series}
                    </span>
                    <h3 className="font-anton text-xl text-white uppercase tracking-wide group-hover:text-[#ddb8ff] transition-colors mt-0.5">
                      {p.title}
                    </h3>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-[#282a2b] mt-2">
                    <span className="font-anton text-lg text-white">
                      ${p.price.toFixed(2)}
                    </span>
                    <span className="text-xs text-[#c9c5cc] flex items-center gap-1">
                      <span>{p.rating}</span>
                      <span className="text-[#ddb8ff]">★</span>
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
