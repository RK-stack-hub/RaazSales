import React, { useState } from 'react';
import { CartItem } from '../types';

interface ExpressCheckoutModalProps {
  isOpen: boolean;
  onClose: () => void;
  items: CartItem[];
  onOrderComplete: () => void;
  appliedDiscount: number;
}

export const ExpressCheckoutModal: React.FC<ExpressCheckoutModalProps> = ({
  isOpen,
  onClose,
  items,
  onOrderComplete,
  appliedDiscount,
}) => {
  const [step, setStep] = useState<'checkout' | 'processing' | 'confirmed'>('checkout');
  const [paymentMethod, setPaymentMethod] = useState<'apple_pay' | 'google_pay' | 'card' | 'cod'>('card');
  const [orderNumber, setOrderNumber] = useState('');

  const [formData, setFormData] = useState({
    name: 'Kaito Jin',
    email: 'kaito.jin@streetwear.tokyo',
    phone: '+1 (555) 438-9214',
    address: '42 Shibuya Crossing Blvd, Apt 7B',
    city: 'Los Angeles',
    state: 'CA',
    postalCode: '90015',
    cardNumber: '•••• •••• •••• 4242',
    cardExpiry: '08/28',
    cardCvc: '•••',
  });

  if (!isOpen) return null;

  const subtotal = items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const discountAmount = subtotal * (appliedDiscount / 100);
  const total = subtotal - discountAmount;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setStep('processing');
    setTimeout(() => {
      const generatedOrder = `ED-G5-${Math.floor(10000 + Math.random() * 90000)}`;
      setOrderNumber(generatedOrder);
      setStep('confirmed');
      onOrderComplete();
    }, 1200);
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-black/90 backdrop-blur-md flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-[#1a1c1c] border border-[#48464b] rounded-2xl max-w-xl w-full p-6 sm:p-8 flex flex-col gap-6 relative shadow-2xl max-h-[95vh] overflow-y-auto text-[#e2e2e2]"
        onClick={(e) => e.stopPropagation()}
      >
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-[#c9c5cc] hover:text-white p-1 rounded-lg"
          aria-label="Close checkout"
        >
          <span className="material-symbols-outlined text-xl">close</span>
        </button>

        {step === 'processing' && (
          <div className="py-20 flex flex-col items-center justify-center text-center gap-4">
            <span className="material-symbols-outlined text-6xl text-[#ddb8ff] animate-spin">
              progress_activity
            </span>
            <h3 className="font-anton text-2xl uppercase text-white tracking-wide">
              Authorizing Express Order
            </h3>
            <p className="text-xs text-[#c9c5cc]">
              Encrypting shipping dispatch credentials and reserving Gear 5 drop inventory...
            </p>
          </div>
        )}

        {step === 'confirmed' && (
          <div className="py-8 flex flex-col items-center text-center gap-4">
            <div className="w-16 h-16 rounded-full bg-emerald-500/20 text-emerald-400 border border-emerald-500/40 flex items-center justify-center">
              <span className="material-symbols-outlined text-4xl">done_all</span>
            </div>
            <div>
              <span className="text-xs uppercase tracking-widest text-emerald-400 font-bold">
                Payment Authorized • Drop Secured
              </span>
              <h3 className="font-anton text-3xl uppercase text-white mt-1">
                Order #{orderNumber} Confirmed!
              </h3>
              <p className="text-xs text-[#c9c5cc] mt-1">
                A confirmation receipt and courier tracking dispatch link have been sent to{' '}
                <strong className="text-white">{formData.email}</strong>.
              </p>
            </div>

            <div className="w-full bg-[#121414] border border-[#282a2b] p-4 rounded-xl text-left text-xs flex flex-col gap-2.5">
              <div className="flex justify-between pb-2 border-b border-[#282a2b]">
                <span className="text-[#c9c5cc]">Shipping Destination:</span>
                <span className="text-white font-semibold">
                  {formData.address}, {formData.city}
                </span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#282a2b]">
                <span className="text-[#c9c5cc]">Estimated Delivery:</span>
                <span className="text-[#ddb8ff] font-semibold">Express 2-Day Air (Oct 25)</span>
              </div>
              <div className="flex justify-between pb-2 border-b border-[#282a2b]">
                <span className="text-[#c9c5cc]">Items Ordered:</span>
                <span className="text-white font-semibold">
                  {items.reduce((s, i) => s + i.quantity, 0)} item(s)
                </span>
              </div>
              <div className="flex justify-between text-sm font-bold pt-1">
                <span className="text-white">Amount Paid:</span>
                <span className="font-anton text-[#ddb8ff] text-base">${total.toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={onClose}
              className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] py-3 rounded-xl font-anton uppercase tracking-wider transition-colors mt-2"
            >
              Continue Streetwear Shopping
            </button>
          </div>
        )}

        {step === 'checkout' && (
          <form onSubmit={handlePlaceOrder} className="flex flex-col gap-5">
            <div>
              <span className="text-xs uppercase tracking-wider text-[#ddb8ff] font-bold">
                Instant Fulfillment
              </span>
              <h3 className="font-anton text-2xl uppercase text-white mt-1">
                Express Checkout
              </h3>
            </div>

            {/* Quick One-Click Pay Methods */}
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              <button
                type="button"
                onClick={() => setPaymentMethod('card')}
                className={`p-2.5 rounded-lg border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'card'
                    ? 'border-[#ddb8ff] bg-[#7c03d3]/20 text-[#ddb8ff]'
                    : 'border-[#48464b] bg-[#121414] text-[#c9c5cc]'
                }`}
              >
                <span className="material-symbols-outlined text-lg">credit_card</span>
                <span>Credit Card</span>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('apple_pay')}
                className={`p-2.5 rounded-lg border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'apple_pay'
                    ? 'border-[#ddb8ff] bg-[#7c03d3]/20 text-[#ddb8ff]'
                    : 'border-[#48464b] bg-[#121414] text-[#c9c5cc]'
                }`}
              >
                <span className="font-bold text-base">Pay</span>
                <span>Apple Pay</span>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('google_pay')}
                className={`p-2.5 rounded-lg border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'google_pay'
                    ? 'border-[#ddb8ff] bg-[#7c03d3]/20 text-[#ddb8ff]'
                    : 'border-[#48464b] bg-[#121414] text-[#c9c5cc]'
                }`}
              >
                <span className="font-bold text-base">GPay</span>
                <span>Google Pay</span>
              </button>
              <button
                type="button"
                onClick={() => setPaymentMethod('cod')}
                className={`p-2.5 rounded-lg border text-xs font-bold flex flex-col items-center gap-1 transition-all ${
                  paymentMethod === 'cod'
                    ? 'border-[#ddb8ff] bg-[#7c03d3]/20 text-[#ddb8ff]'
                    : 'border-[#48464b] bg-[#121414] text-[#c9c5cc]'
                }`}
              >
                <span className="material-symbols-outlined text-lg">payments</span>
                <span>Cash on Delivery</span>
              </button>
            </div>

            {/* Shipping Info */}
            <div className="flex flex-col gap-3">
              <span className="text-xs uppercase tracking-wider text-white font-semibold">
                Delivery Address
              </span>
              <div className="grid grid-cols-2 gap-3 text-xs">
                <input
                  type="text"
                  placeholder="Full Name"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="bg-[#121414] border border-[#48464b] rounded p-2 text-white"
                />
                <input
                  type="email"
                  placeholder="Email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="bg-[#121414] border border-[#48464b] rounded p-2 text-white"
                />
                <input
                  type="text"
                  placeholder="Street Address"
                  required
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="col-span-2 bg-[#121414] border border-[#48464b] rounded p-2 text-white"
                />
                <input
                  type="text"
                  placeholder="City"
                  required
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="bg-[#121414] border border-[#48464b] rounded p-2 text-white"
                />
                <input
                  type="text"
                  placeholder="Postal Code"
                  required
                  value={formData.postalCode}
                  onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                  className="bg-[#121414] border border-[#48464b] rounded p-2 text-white"
                />
              </div>
            </div>

            {/* Order Items Preview */}
            <div className="bg-[#121414] p-3 rounded-xl border border-[#282a2b] flex flex-col gap-2 text-xs">
              <span className="uppercase text-[10px] tracking-wider text-[#c9c5cc] font-semibold">
                Items in Order ({items.length})
              </span>
              {items.map((i, idx) => (
                <div key={idx} className="flex justify-between items-center text-[#c9c5cc]">
                  <span className="truncate max-w-[260px] text-white">
                    {i.quantity}x {i.title} ({i.size})
                  </span>
                  <span className="font-mono">${(i.price * i.quantity).toFixed(2)}</span>
                </div>
              ))}
              <div className="pt-2 border-t border-[#282a2b] flex justify-between font-bold text-white text-sm">
                <span>Total Amount Due</span>
                <span className="font-anton text-[#ddb8ff] text-base">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Submit */}
            <button
              type="submit"
              className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] py-3.5 rounded-xl font-anton text-base uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(124,3,211,0.4)] flex items-center justify-center gap-2"
            >
              <span className="material-symbols-outlined text-lg">lock</span>
              <span>Authorize Payment &amp; Place Order (${total.toFixed(2)})</span>
            </button>
          </form>
        )}
      </div>
    </div>
  );
};
