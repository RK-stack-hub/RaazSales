import React, { useState } from 'react';
import { Review } from '../types';

interface ReviewsSectionProps {
  reviews: Review[];
  onOpenWriteReview: () => void;
}

export const ReviewsSection: React.FC<ReviewsSectionProps> = ({ reviews, onOpenWriteReview }) => {
  const [filterRating, setFilterRating] = useState<number | 'all'>('all');

  const filteredReviews = reviews.filter((r) => {
    if (filterRating === 'all') return true;
    return r.rating === filterRating;
  });

  return (
    <section id="reviews-section" className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 w-full flex flex-col gap-10">
      {/* Header & Write Review Action */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 pb-6 border-b border-[#282a2b]">
        <div>
          <h2 className="font-anton text-3xl sm:text-4xl uppercase tracking-wide text-white">
            Verified Customer Reviews
          </h2>
          <p className="text-sm text-[#c9c5cc] mt-1">
            Based on 1,240 global reviews for the Gear 5 Drop.
          </p>
        </div>
        <button
          onClick={onOpenWriteReview}
          className="bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] px-6 py-3 rounded-xl font-anton text-base uppercase tracking-wider transition-all shadow-[0_0_20px_rgba(124,3,211,0.3)] hover:shadow-[0_0_25px_rgba(221,184,255,0.5)] flex items-center gap-2"
        >
          <span className="material-symbols-outlined text-lg">rate_review</span>
          <span>Write a Review</span>
        </button>
      </div>

      {/* Review Stats & Cards Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
        {/* Breakdown Summary (4 cols) */}
        <div className="lg:col-span-4 bg-[#1a1c1c] p-6 sm:p-8 rounded-xl flex flex-col gap-6 border border-[#282a2b] lg:sticky lg:top-28">
          <div className="flex items-center gap-4">
            <span className="font-anton text-5xl text-white">4.8</span>
            <div className="flex flex-col gap-1">
              <div className="flex text-[#ddb8ff]">
                {[...Array(5)].map((_, i) => (
                  <span
                    key={i}
                    className="material-symbols-outlined text-[20px]"
                    style={{ fontVariationSettings: "'FILL' 1" }}
                  >
                    star
                  </span>
                ))}
              </div>
              <span className="text-xs text-[#c9c5cc]">Out of 5.0 stars</span>
            </div>
          </div>

          {/* Star Distribution Bars */}
          <div className="flex flex-col gap-2.5">
            {[
              { star: 5, pct: 85 },
              { star: 4, pct: 12 },
              { star: 3, pct: 2 },
              { star: 2, pct: 1 },
              { star: 1, pct: 0 },
            ].map((row) => (
              <button
                key={row.star}
                onClick={() => setFilterRating(filterRating === row.star ? 'all' : row.star)}
                className={`flex items-center gap-3 text-xs w-full text-left p-1 rounded hover:bg-[#282a2b] transition-colors ${
                  filterRating === row.star ? 'bg-[#282a2b] text-[#ddb8ff]' : 'text-white'
                }`}
                title={`Filter by ${row.star} stars`}
              >
                <span className="w-10 whitespace-nowrap">{row.star} Star</span>
                <div className="flex-1 h-2 bg-[#282a2b] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-[#ddb8ff] rounded-full transition-all duration-500"
                    style={{ width: `${row.pct}%` }}
                  ></div>
                </div>
                <span className="text-[#c9c5cc] w-8 text-right font-mono">{row.pct}%</span>
              </button>
            ))}
          </div>

          {/* Fit Feedback Meter */}
          <div className="pt-5 border-t border-[#282a2b] flex flex-col gap-2.5">
            <span className="text-xs uppercase tracking-wider text-white font-semibold">
              Fit Feedback
            </span>
            <div className="flex justify-between text-xs text-[#c9c5cc]">
              <span>Runs Small</span>
              <span className="text-[#ddb8ff] font-bold">True to Size (94%)</span>
              <span>Runs Large</span>
            </div>
            <div className="w-full h-2.5 bg-[#282a2b] rounded-full overflow-hidden relative">
              <div
                className="h-full bg-gradient-to-r from-[#7c03d3] to-[#ddb8ff] rounded-full"
                style={{ width: '94%', marginLeft: '3%' }}
              ></div>
            </div>
          </div>
        </div>

        {/* Review Cards List (8 cols) */}
        <div className="lg:col-span-8 flex flex-col gap-4">
          {filterRating !== 'all' && (
            <div className="flex items-center justify-between bg-[#1e2020] px-4 py-2 rounded-lg border border-[#282a2b] text-xs">
              <span>
                Filtering by <strong>{filterRating} Star Reviews</strong>
              </span>
              <button
                onClick={() => setFilterRating('all')}
                className="text-[#ddb8ff] hover:underline"
              >
                Show All ({reviews.length})
              </button>
            </div>
          )}

          {filteredReviews.map((rev) => (
            <div
              key={rev.id}
              className="bg-[#1a1c1c] p-6 sm:p-7 rounded-xl flex flex-col gap-4 border border-[#282a2b] hover:border-[#48464b] transition-colors"
            >
              <div className="flex justify-between items-start">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-[#7c03d3] text-[#dfbcff] flex items-center justify-center font-bold text-sm">
                    {rev.avatarInitials}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-semibold text-white text-sm">{rev.author}</span>
                      {rev.verified && (
                        <span className="bg-[#282a2b] text-[#ddb8ff] text-[10px] px-1.5 py-0.5 rounded uppercase font-bold flex items-center gap-0.5">
                          <span className="material-symbols-outlined text-[12px]">verified</span>
                          <span>Verified</span>
                        </span>
                      )}
                    </div>
                    <span className="text-xs text-[#c9c5cc] block mt-0.5">
                      Verified Buyer • {rev.size} • {rev.color}
                    </span>
                  </div>
                </div>
                <span className="text-xs text-[#928f96]">{rev.date}</span>
              </div>

              {/* Stars */}
              <div className="flex text-[#ddb8ff]">
                {[...Array(5)].map((_, i) => (
                  <span
                    key={i}
                    className="material-symbols-outlined text-[16px]"
                    style={{ fontVariationSettings: i < rev.rating ? "'FILL' 1" : "'FILL' 0" }}
                  >
                    star
                  </span>
                ))}
              </div>

              {/* Comment text */}
              <p className="text-sm text-[#e2e2e2] leading-relaxed">{rev.comment}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
