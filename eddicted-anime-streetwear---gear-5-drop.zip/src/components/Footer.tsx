import React, { useState } from 'react';

interface FooterProps {
  onOpenSizeGuide: () => void;
  onNavigateDrops: () => void;
}

export const Footer: React.FC<FooterProps> = ({ onOpenSizeGuide, onNavigateDrops }) => {
  const [email, setEmail] = useState('');
  const [joined, setJoined] = useState(false);
  const [activeModal, setActiveModal] = useState<string | null>(null);

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email.trim() || !email.includes('@')) return;
    setJoined(true);
    setTimeout(() => {
      setEmail('');
    }, 3000);
  };

  return (
    <footer className="w-full bg-[#1a1c1c] py-16 border-t border-[#282a2b] text-[#e2e2e2]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
        {/* Brand Col */}
        <div className="flex flex-col gap-4">
          <span className="font-anton text-2xl uppercase tracking-wider text-white">
            EDDICTED
          </span>
          <p className="text-xs text-[#c9c5cc] leading-relaxed max-w-xs">
            High-energy streetwear inspired by rebellious anime subculture. Crafted for the vanguard.
          </p>
          <div className="flex items-center gap-2 text-xs text-[#ddb8ff]">
            <span className="material-symbols-outlined text-sm">verified_user</span>
            <span>Official Licensed Apparel Partner</span>
          </div>
        </div>

        {/* Navigation */}
        <div className="flex flex-col gap-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-white">
            Navigation
          </span>
          <button
            onClick={onNavigateDrops}
            className="text-xs text-[#c9c5cc] hover:text-white transition-colors text-left"
          >
            Latest Drops
          </button>
          <button
            onClick={onNavigateDrops}
            className="text-xs text-[#c9c5cc] hover:text-white transition-colors text-left"
          >
            Outerwear
          </button>
          <button
            onClick={onNavigateDrops}
            className="text-xs text-[#c9c5cc] hover:text-white transition-colors text-left"
          >
            Hoodies &amp; Tees
          </button>
          <button
            onClick={onNavigateDrops}
            className="text-xs text-[#c9c5cc] hover:text-white transition-colors text-left"
          >
            Archive
          </button>
        </div>

        {/* Support */}
        <div className="flex flex-col gap-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-white">
            Support
          </span>
          <button
            onClick={() => setActiveModal('Order Tracking')}
            className="text-xs text-[#c9c5cc] hover:text-white transition-colors text-left"
          >
            Order Tracking
          </button>
          <button
            onClick={() => setActiveModal('Shipping & Returns')}
            className="text-xs text-[#c9c5cc] hover:text-white transition-colors text-left"
          >
            Shipping &amp; Returns
          </button>
          <button
            onClick={onOpenSizeGuide}
            className="text-xs text-[#c9c5cc] hover:text-white transition-colors text-left"
          >
            Size Matrix
          </button>
          <button
            onClick={() => setActiveModal('Contact Us')}
            className="text-xs text-[#c9c5cc] hover:text-white transition-colors text-left"
          >
            Contact Us
          </button>
        </div>

        {/* Stay Plugged In Newsletter */}
        <div className="flex flex-col gap-3">
          <span className="text-xs font-semibold uppercase tracking-wider text-white">
            Stay Plugged In
          </span>
          <p className="text-xs text-[#c9c5cc]">
            Get early access alerts for secret limited drops.
          </p>
          {joined ? (
            <div className="bg-emerald-500/10 border border-emerald-500/40 p-2.5 rounded-lg text-emerald-400 text-xs font-semibold flex items-center gap-1.5 animate-in fade-in">
              <span className="material-symbols-outlined text-base">check_circle</span>
              <span>You're on the VIP Drop List! Check inbox.</span>
            </div>
          ) : (
            <form onSubmit={handleJoin} className="flex gap-2">
              <input
                type="email"
                required
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-[#1e2020] border border-[#48464b] px-3 py-2 text-xs text-white rounded flex-1 focus:outline-none focus:border-[#7c03d3]"
              />
              <button
                type="submit"
                className="bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] px-4 py-2 text-xs font-bold uppercase rounded transition-colors whitespace-nowrap"
              >
                Join
              </button>
            </form>
          )}
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 border-t border-[#282a2b] flex flex-col md:flex-row justify-between items-center text-xs text-[#928f96] gap-3">
        <p>© 2024 EDDICTED APPAREL. ALL RIGHTS RESERVED.</p>
        <div className="flex gap-6">
          <button
            onClick={() => setActiveModal('Privacy Policy')}
            className="hover:text-white transition-colors"
          >
            Privacy Policy
          </button>
          <button
            onClick={() => setActiveModal('Terms of Service')}
            className="hover:text-white transition-colors"
          >
            Terms of Service
          </button>
        </div>
      </div>

      {/* Quick Info Modal for Support links */}
      {activeModal && (
        <div
          className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 text-[#e2e2e2]"
          onClick={() => setActiveModal(null)}
        >
          <div
            className="bg-[#1a1c1c] border border-[#48464b] rounded-2xl max-w-md w-full p-6 flex flex-col gap-4 relative shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <button
              onClick={() => setActiveModal(null)}
              className="absolute top-4 right-4 text-[#c9c5cc] hover:text-white"
              aria-label="Close modal"
            >
              <span className="material-symbols-outlined text-xl">close</span>
            </button>
            <h3 className="font-anton text-2xl uppercase text-white">{activeModal}</h3>
            {activeModal === 'Order Tracking' && (
              <div className="text-xs text-[#c9c5cc] flex flex-col gap-3">
                <p>Track your anime streetwear package in real-time worldwide.</p>
                <div className="flex gap-2">
                  <input
                    type="text"
                    defaultValue="ED-G5-48291"
                    placeholder="Enter Order #"
                    className="flex-1 bg-[#121414] border border-[#48464b] rounded p-2 text-white"
                  />
                  <button className="bg-[#7c03d3] text-white px-3 py-2 rounded text-xs font-bold uppercase">
                    Track
                  </button>
                </div>
                <div className="bg-[#121414] p-3 rounded border border-[#282a2b] text-[11px]">
                  <p className="text-emerald-400 font-bold">Status: Out for Air Express Courier</p>
                  <p className="text-[#928f96]">Carrier: DHL Express Anime Dispatch</p>
                </div>
              </div>
            )}
            {activeModal === 'Shipping & Returns' && (
              <div className="text-xs text-[#c9c5cc] flex flex-col gap-2">
                <p>• <strong>Free Worldwide Express Shipping:</strong> Orders over $50 qualify for express air freight (2-4 business days).</p>
                <p>• <strong>30-Day Hassle-Free Returns:</strong> Unworn tees with original tags and packaging are 100% refundable.</p>
                <p>• <strong>Customs & Duties:</strong> All duties and taxes are prepaid and included at checkout.</p>
              </div>
            )}
            {activeModal === 'Contact Us' && (
              <div className="text-xs text-[#c9c5cc] flex flex-col gap-2">
                <p>Our Tokyo &amp; Los Angeles headquarters support team is ready 24/7:</p>
                <p className="text-white font-mono">support@eddicted-apparel.com</p>
                <p className="text-white font-mono">Discord: #eddicted-support</p>
              </div>
            )}
            {(activeModal === 'Privacy Policy' || activeModal === 'Terms of Service') && (
              <div className="text-xs text-[#c9c5cc] flex flex-col gap-2">
                <p>All client data is encrypted with 256-bit SSL protocols. We never sell customer credentials. All anime apparel designs are officially licensed by their respective production committees.</p>
              </div>
            )}
            <button
              onClick={() => setActiveModal(null)}
              className="w-full bg-[#282a2b] hover:bg-[#333535] text-white py-2 rounded-lg text-xs font-anton uppercase tracking-wider transition-colors mt-2"
            >
              Close
            </button>
          </div>
        </div>
      )}
    </footer>
  );
};
