import React, { useState } from 'react';
import { USER_AVATAR } from '../data/products';

interface HeaderProps {
  cartCount: number;
  wishlistCount: number;
  currentView: 'home' | 'drops' | 'lookbook';
  onNavigate: (view: 'home' | 'drops' | 'lookbook') => void;
  onOpenCart: () => void;
  onOpenWishlist: () => void;
  onOpenSearch: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  cartCount,
  wishlistCount,
  currentView,
  onNavigate,
  onOpenCart,
  onOpenWishlist,
  onOpenSearch,
}) => {
  const [showPromo, setShowPromo] = useState(true);
  const [copiedCode, setCopiedCode] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [showProfileMenu, setShowProfileMenu] = useState(false);

  const handleCopyCode = () => {
    navigator.clipboard?.writeText('GEAR5VIP');
    setCopiedCode(true);
    setTimeout(() => setCopiedCode(false), 2000);
  };

  return (
    <div className="w-full">
      {/* Top Announcement Bar */}
      {showPromo && (
        <div className="w-full bg-[#7c03d3] text-[#dfbcff] text-center py-2 px-4 text-xs font-semibold uppercase tracking-wider flex items-center justify-center gap-2 relative">
          <span>⚡ Gear 5 Drop Live Now — Free Express Shipping Worldwide on Orders Over $150 ⚡</span>
          <button
            onClick={handleCopyCode}
            className="hidden sm:inline-flex items-center gap-1 bg-[#1b0033]/60 hover:bg-[#1b0033] px-2 py-0.5 rounded text-[11px] font-bold text-white transition-all ml-2 border border-[#dfbcff]/30"
            title="Click to copy VIP code"
          >
            {copiedCode ? '✓ Copied CODE!' : 'Use Code: GEAR5VIP'}
          </button>
          <button
            onClick={() => setShowPromo(false)}
            aria-label="Close Announcement"
            className="absolute right-3 top-1/2 -translate-y-1/2 opacity-70 hover:opacity-100 p-1"
          >
            <span className="material-symbols-outlined text-sm">close</span>
          </button>
        </div>
      )}

      {/* Main Sticky Header */}
      <header className="sticky top-0 z-40 bg-[#121414]/90 backdrop-blur-xl border-b border-[#282a2b]">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-20 flex items-center justify-between">
          {/* Mobile menu trigger */}
          <div className="flex items-center lg:hidden mr-2">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="p-2 text-[#c9c5cc] hover:text-[#e2e2e2] transition-colors focus:outline-none"
              aria-label="Toggle navigation menu"
            >
              <span className="material-symbols-outlined text-2xl">
                {mobileMenuOpen ? 'close' : 'menu'}
              </span>
            </button>
          </div>

          {/* Brand Wordmark (Anton font, uppercase) */}
          <button
            onClick={() => {
              onNavigate('home');
              setMobileMenuOpen(false);
            }}
            className="font-anton text-2xl md:text-3xl tracking-widest uppercase text-[#e2e2e2] hover:text-[#ddb8ff] transition-colors focus:outline-none"
          >
            EDDICTED
          </button>

          {/* Desktop Navigation Links */}
          <nav className="hidden lg:flex items-center gap-8">
            <button
              onClick={() => onNavigate('home')}
              className={`text-sm tracking-wide font-medium transition-colors ${
                currentView === 'home'
                  ? 'text-[#c9c4d2] font-bold border-b-2 border-[#7c03d3] pb-1'
                  : 'text-[#c9c5cc] hover:text-[#e2e2e2]'
              }`}
            >
              Home
            </button>
            <button
              onClick={() => onNavigate('drops')}
              className={`text-sm tracking-wide font-medium transition-colors ${
                currentView === 'drops'
                  ? 'text-[#c9c4d2] font-bold border-b-2 border-[#7c03d3] pb-1'
                  : 'text-[#c9c5cc] hover:text-[#e2e2e2]'
              }`}
            >
              Drops
            </button>
            <button
              onClick={() => onNavigate('drops')}
              className="text-sm tracking-wide font-medium text-[#c9c5cc] hover:text-[#e2e2e2] transition-colors"
            >
              Apparel
            </button>
            <button
              onClick={() => onNavigate('drops')}
              className="text-sm tracking-wide font-medium text-[#c9c5cc] hover:text-[#e2e2e2] transition-colors"
            >
              Accessories
            </button>
            <button
              onClick={() => onNavigate('lookbook')}
              className={`text-sm tracking-wide font-medium transition-colors ${
                currentView === 'lookbook'
                  ? 'text-[#c9c4d2] font-bold border-b-2 border-[#7c03d3] pb-1'
                  : 'text-[#c9c5cc] hover:text-[#e2e2e2]'
              }`}
            >
              Lookbook
            </button>
          </nav>

          {/* Action Icons */}
          <div className="flex items-center gap-1 sm:gap-3">
            {/* Search */}
            <button
              onClick={onOpenSearch}
              className="p-2 text-[#c9c5cc] hover:text-[#e2e2e2] transition-colors rounded-lg hover:bg-[#1e2020]"
              title="Search streetwear drops"
              aria-label="Search"
            >
              <span className="material-symbols-outlined text-[22px]">search</span>
            </button>

            {/* Wishlist */}
            <button
              onClick={onOpenWishlist}
              className="p-2 text-[#c9c5cc] hover:text-[#e2e2e2] transition-colors rounded-lg hover:bg-[#1e2020] relative"
              title="View Wishlist"
              aria-label="Wishlist"
            >
              <span className="material-symbols-outlined text-[22px]">favorite</span>
              {wishlistCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#7c03d3] text-[#dfbcff] text-[10px] font-bold flex items-center justify-center rounded-full">
                  {wishlistCount}
                </span>
              )}
            </button>

            {/* Shopping Bag / Cart */}
            <button
              onClick={onOpenCart}
              className="p-2 text-[#c9c5cc] hover:text-[#e2e2e2] transition-colors rounded-lg hover:bg-[#1e2020] relative"
              title="Shopping Bag"
              aria-label="Cart"
            >
              <span className="material-symbols-outlined text-[22px]">shopping_bag</span>
              {cartCount > 0 && (
                <span className="absolute top-1 right-1 w-4 h-4 bg-[#7c03d3] text-[#dfbcff] text-[10px] font-bold flex items-center justify-center rounded-full animate-pulse">
                  {cartCount}
                </span>
              )}
            </button>

            {/* Profile Avatar & Quick Status */}
            <div className="relative">
              <button
                onClick={() => setShowProfileMenu(!showProfileMenu)}
                className="flex items-center gap-2 p-1 rounded-full hover:ring-2 hover:ring-[#7c03d3] transition-all ml-1 focus:outline-none"
                aria-label="User Account"
              >
                <img
                  src={USER_AVATAR}
                  alt="Profile"
                  referrerPolicy="no-referrer"
                  className="w-8 h-8 rounded-full object-cover border border-[#48464b]"
                />
              </button>

              {/* Profile dropdown */}
              {showProfileMenu && (
                <div className="absolute right-0 mt-2 w-64 bg-[#1a1c1c] border border-[#48464b] rounded-xl shadow-2xl p-4 z-50 flex flex-col gap-3">
                  <div className="flex items-center gap-3 pb-3 border-b border-[#282a2b]">
                    <img
                      src={USER_AVATAR}
                      alt="User"
                      referrerPolicy="no-referrer"
                      className="w-10 h-10 rounded-full object-cover"
                    />
                    <div>
                      <p className="text-sm font-bold text-[#e2e2e2]">Kaito Jin</p>
                      <p className="text-xs text-[#ddb8ff]">Awakened VIP Tier</p>
                    </div>
                  </div>
                  <div className="flex flex-col gap-2 text-xs text-[#c9c5cc]">
                    <div className="flex justify-between py-1">
                      <span>Loyalty Reward Points</span>
                      <span className="font-bold text-white">480 PTS</span>
                    </div>
                    <div className="flex justify-between py-1">
                      <span>Active Orders</span>
                      <span className="font-bold text-emerald-400">1 In Transit</span>
                    </div>
                  </div>
                  <button
                    onClick={() => {
                      onOpenCart();
                      setShowProfileMenu(false);
                    }}
                    className="w-full bg-[#7c03d3] hover:bg-[#ddb8ff] text-[#dfbcff] hover:text-[#490080] font-bold py-2 rounded-lg text-xs uppercase tracking-wider transition-colors"
                  >
                    View Shopping Bag ({cartCount})
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation Dropdown */}
        {mobileMenuOpen && (
          <div className="lg:hidden bg-[#1a1c1c] border-b border-[#282a2b] px-6 py-4 flex flex-col gap-4 animate-in slide-in-from-top duration-200">
            <button
              onClick={() => {
                onNavigate('home');
                setMobileMenuOpen(false);
              }}
              className="text-left font-medium py-2 text-[#e2e2e2] border-b border-[#282a2b]"
            >
              Home (Gear 5 Showcase)
            </button>
            <button
              onClick={() => {
                onNavigate('drops');
                setMobileMenuOpen(false);
              }}
              className="text-left font-medium py-2 text-[#c9c5cc] hover:text-white border-b border-[#282a2b]"
            >
              All Drops
            </button>
            <button
              onClick={() => {
                onNavigate('drops');
                setMobileMenuOpen(false);
              }}
              className="text-left font-medium py-2 text-[#c9c5cc] hover:text-white border-b border-[#282a2b]"
            >
              Apparel & Tees
            </button>
            <button
              onClick={() => {
                onNavigate('lookbook');
                setMobileMenuOpen(false);
              }}
              className="text-left font-medium py-2 text-[#c9c5cc] hover:text-white"
            >
              Anime Streetwear Lookbook
            </button>
          </div>
        )}
      </header>
    </div>
  );
};
