import { Product, Review } from '../types';

export const GEAR_5_IMAGE =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuCLthHmmgLD56UVj0IZ2rhkyBhflB3qDRxYzA8MRDj5BsJSRbuSVPp79cbuv_MWGApRWkxJ26iiiiE87vrcdykLw0RgNDqVbqCKoE6424A2IVNdO-tIbSakkS7JuhICVCnD9z_naWpdQLPB4KxAP1GMczCwL87tqdcfr27D5AIIsI850m3ZwA9WXrqIrclz9EoM1Xxw9UeoLttk3a9JN7tZe4illvEW2RyTWGYUwonILIjLJQeqg93X7x26-gqQEU_kPA';

export const ZORO_IMAGE =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuD4GjXfcYoGf0YuQ2oBuQNA5IEYkOwsbFiL__I17WVC5OgvlrYIa-weXSc1kbZuimoBdfAO32wnzBbjjc_tRP_zYIBvrsJlKEvHTJhEQcNA9wK5uS2sd6djGE4GYEHvT8U3JPhcRxTcXwHaZG63PDwL8kdmFinzdEL2g4zy1375Bf_YbLaiVrbt66hmL8F96OTS7tZx2oFjIj6Emlrbxs6mUG4tNkFm-EHlc6feYfitWZqwEcaHSUNi';

export const SANJI_IMAGE =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuDDV7QKJmJbh1soQM5P4aA740zNHanbVhRU3pstOuZmM_R1rArfBTl0KVU-UJFlrvDpTXkTunmtTs368B8sph5UzjpxVXSPkOPD00fvINKjdNWabogr1M688PsWI_07qaYF_RcgOZaPpjob6_cq6pye3GF1Dd1iOCyLTfSBcuIvY6nMzlaV4a2u378FNq7YPNY7uY_2dgB6gEdp7n5xKcxtiE880mkYlnyKbquAeXvqXeEThPKHVSm4';

export const LAW_IMAGE =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuCIEoJ2DYUrdQ1iQ6MWTorYoYBXvTyJqmBpdZudoBhWJz_LNobsX7PvfIaMUTFnbObJ5QmgrYy0Ix_7DJcrrhNxliikqpv3LFaD8Ggw0XCNRZYLO7Ph_brzbuMKqGL8rX9nkcQ0_mxC1eLKg5gX9aw41tOXQx3NgDjejuvfQsl5P_meh1UeeJo-M7sCYzKy4_EYvZ8DAQPrEsazbHvQM1KMp4libGW3Qwv5F3MOFGkA-mcttncE0WE0';

export const USER_AVATAR =
  'https://lh3.googleusercontent.com/aida-public/AB6AXuAZDzbAoJgk2ldwO4LD0V6wrVc8SqBOL25yr3oa0XSQypGNH-kpivjF8VDLnFbf4MGgUY5grsj1W1neE2-zp9qR-JnFQ9McdyFs-OQaYjQZ2kl-3pHZb0fHYqrx_ZFmNIUuFXShx7ON0OmqqEgOEoDvuHPJHE5EOZzrO-fQEMFyJ2qCs9Cut95Wq3zEao9_7YH-HOe6bFmWbDQdT-pqSbOwgq-iOBIPRwKAWLrUcS9AuZM8JLUIhEtn';

export const FLAGSHIP_PRODUCT: Product = {
  id: 'gear-5-tee',
  sku: 'ED-G5-PRPL',
  title: 'Men Printed V Neck Cotton Blend Purple T-Shirt (Gear 5 Awakened Edition)',
  series: 'EDDICTED / One Piece Licensed Collection',
  category: 'Anime Collection',
  tag: 'Gear 5 Limited Drop',
  price: 34.99,
  originalPrice: 59.99,
  discountPercent: 42,
  rating: 4.8,
  reviewCount: 1240,
  description:
    'Channel the chaotic freedom of Sun God Nika with this heavyweight V-neck tee. Designed with ultra-dense 240 GSM combed cotton, custom ribbed neck ribbing, and tactile DTG high-definition anime graphics that never crack.',
  colors: [
    {
      name: 'Purple',
      hex: '#7c03d3',
      images: {
        front: GEAR_5_IMAGE,
        back: GEAR_5_IMAGE,
        detail: GEAR_5_IMAGE,
        lifestyle: GEAR_5_IMAGE,
      },
    },
    {
      name: 'White',
      hex: '#37393a',
      images: {
        front: GEAR_5_IMAGE,
        back: GEAR_5_IMAGE,
        detail: GEAR_5_IMAGE,
        lifestyle: GEAR_5_IMAGE,
      },
    },
    {
      name: 'Black',
      hex: '#0c0f0f',
      images: {
        front: GEAR_5_IMAGE,
        back: GEAR_5_IMAGE,
        detail: GEAR_5_IMAGE,
        lifestyle: GEAR_5_IMAGE,
      },
    },
  ],
  sizes: ['S', 'M', 'L', 'XL', 'XXL'],
  stockLeft: 14,
  features: [
    {
      title: 'Premium V-Neck Collar',
      desc: 'Constructed with high-tension ribbed purple-white striping that holds its shape wash after wash without sagging or curling.',
      icon: 'hotel_class',
    },
    {
      title: 'High Quality DTG Print',
      desc: 'Luffy Gear 5 Sun God Nika awakening design printed with ultra-vibrant direct-to-garment inks for maximum tactile depth and fade resistance.',
      icon: 'auto_awesome',
    },
    {
      title: 'Sleeve & Back Badges',
      desc: 'Features signature Mugiwara branding and a woven devil fruit sleeve patch verifying authentic licensed anime apparel status.',
      icon: 'verified',
    },
  ],
  specifications: {
    material: '92% Heavy Combed Cotton, 8% Elastane Ribbing',
    weight: '240 GSM Heavyweight Streetwear Knit',
    fit: 'Relaxed Streetwear Box Fit (Drop Shoulder)',
    care: 'Cold Machine Wash inside-out, Tumble Dry Low, Do not iron on DTG print',
    origin: 'Crafted under official Toei Animation x Eddicted Apparel License',
  },
};

export const RELATED_PRODUCTS: Product[] = [
  {
    id: 'zoro-katana-slash-tee',
    sku: 'ED-OP-ZRO',
    title: 'Zoro Katana Slash Tee',
    series: 'Three Sword Style',
    category: 'Men / T-Shirts',
    tag: 'Limited',
    price: 34.99,
    originalPrice: 55.0,
    discountPercent: 36,
    rating: 4.9,
    reviewCount: 948,
    description:
      'Channel the power of the three katana blades with high-density glow green ink on jet black heavyweight tee.',
    colors: [
      {
        name: 'Black',
        hex: '#0c0f0f',
        images: {
          front: ZORO_IMAGE,
          back: ZORO_IMAGE,
          detail: ZORO_IMAGE,
          lifestyle: ZORO_IMAGE,
        },
      },
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    stockLeft: 8,
    features: [
      {
        title: 'Glow Slashing Inks',
        desc: 'Custom green photoluminescent accents that highlight Enma and Wado Ichimonji blade trails.',
        icon: 'swords',
      },
      {
        title: 'Asymmetric Shoulder Cut',
        desc: 'Tailored for oversized modern Japanese street silhouette.',
        icon: 'straighten',
      },
      {
        title: 'Pirate Hunter Insignia',
        desc: 'Woven hem label with Zoro jolly roger and bandana icon.',
        icon: 'verified',
      },
    ],
    specifications: {
      material: '100% Ring-Spun Cotton',
      weight: '230 GSM Heavy Knit',
      fit: 'Oversized Boxy Fit',
      care: 'Machine Wash Cold',
      origin: 'Eddicted One Piece Series',
    },
  },
  {
    id: 'sanji-flame-kick-tee',
    sku: 'ED-OP-SNJ',
    title: 'Sanji Flame Kick Tee',
    series: 'Diable Jambe',
    category: 'Men / T-Shirts',
    tag: 'Bestseller',
    price: 36.99,
    originalPrice: 60.0,
    discountPercent: 38,
    rating: 4.8,
    reviewCount: 820,
    description:
      'Premium heavyweight cotton with blazing Diable Jambe fiery anime typography and heat-treated graphics.',
    colors: [
      {
        name: 'Crimson Ember',
        hex: '#93000a',
        images: {
          front: SANJI_IMAGE,
          back: SANJI_IMAGE,
          detail: SANJI_IMAGE,
          lifestyle: SANJI_IMAGE,
        },
      },
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    stockLeft: 19,
    features: [
      {
        title: 'Thermal Gradient Print',
        desc: 'Multi-layer fiery halftone print with ultra-deep red and gold tones.',
        icon: 'local_fire_department',
      },
      {
        title: 'Ribbed Vintage Collar',
        desc: 'Reinforced 1.2-inch collar ribbing prevents bacon-neck after multiple washes.',
        icon: 'hotel_class',
      },
      {
        title: 'Black Leg Chef Patch',
        desc: 'Embroidered Baratie cooking fork patch on left sleeve.',
        icon: 'verified',
      },
    ],
    specifications: {
      material: '100% Pre-Shrunk Cotton',
      weight: '240 GSM',
      fit: 'Relaxed Fit',
      care: 'Cold wash inside-out',
      origin: 'Eddicted One Piece Series',
    },
  },
  {
    id: 'law-room-tech-tee',
    sku: 'ED-OP-LAW',
    title: 'Law Room Tech Tee',
    series: 'Ope Ope No Mi',
    category: 'Men / T-Shirts',
    tag: 'Restocked',
    price: 34.99,
    originalPrice: 55.0,
    discountPercent: 36,
    rating: 4.9,
    reviewCount: 1102,
    description:
      'Surgical Room motif purple and black streetwear tee with minimalist anime iconography and Heart Pirates tech-specs.',
    colors: [
      {
        name: 'Surgical Black',
        hex: '#0c0f0f',
        images: {
          front: LAW_IMAGE,
          back: LAW_IMAGE,
          detail: LAW_IMAGE,
          lifestyle: LAW_IMAGE,
        },
      },
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    stockLeft: 23,
    features: [
      {
        title: 'Heart Pirates Crest',
        desc: 'Crisp geometric print of Trafalgar Law smiling death crest.',
        icon: 'favorite',
      },
      {
        title: 'DEATH Knuckle Detail',
        desc: 'Screen-printed sleeve cuff script inspired by Law iconic finger tattoos.',
        icon: 'draw',
      },
      {
        title: 'Breathable Pima Blend',
        desc: 'Ultra-soft handfeel with enhanced moisture-wicking properties.',
        icon: 'air',
      },
    ],
    specifications: {
      material: '95% Pima Cotton, 5% Spandex',
      weight: '220 GSM',
      fit: 'Modern Street Fit',
      care: 'Delicate Cold Wash',
      origin: 'Eddicted One Piece Series',
    },
  },
];

export const INITIAL_REVIEWS: Review[] = [
  {
    id: 'rev-1',
    author: 'Kenji A.',
    avatarInitials: 'KA',
    verified: true,
    size: 'Size L',
    color: 'Purple',
    date: '2 days ago',
    rating: 5,
    comment:
      'Absolute masterpiece of a tee. The print quality on the Gear 5 awakening is insane, and the V-neck ribbing has great tension. Wore it to my local meetup and got tons of compliments!',
    fitVote: 'true-to-size',
  },
  {
    id: 'rev-2',
    author: 'Sarah M.',
    avatarInitials: 'SM',
    verified: true,
    size: 'Size M',
    color: 'Purple',
    date: '1 week ago',
    rating: 5,
    comment:
      'Super soft cotton blend, breathable for summer conventions, and the sleeve devil fruit patch is a gorgeous touch. Fast shipping too!',
    fitVote: 'true-to-size',
  },
  {
    id: 'rev-3',
    author: 'Daisuke T.',
    avatarInitials: 'DT',
    verified: true,
    size: 'Size XL',
    color: 'Purple',
    date: '2 weeks ago',
    rating: 5,
    comment:
      'The purple saturation in real life is even better than in the studio photos. Fits boxy just like proper Tokyo streetwear. 10/10 cop.',
    fitVote: 'true-to-size',
  },
  {
    id: 'rev-4',
    author: 'Marcus R.',
    avatarInitials: 'MR',
    verified: true,
    size: 'Size XXL',
    color: 'Black',
    date: '3 weeks ago',
    rating: 4,
    comment:
      'Heavy fabric that does not crease easily. Wash cold to keep the contrast sharp. Looking forward to the next Luffy drop!',
    fitVote: 'runs-small',
  },
];
