export interface ProductColor {
  name: string;
  hex: string;
  borderClass?: string;
  images: {
    front: string;
    back: string;
    detail: string;
    lifestyle: string;
  };
}

export interface Product {
  id: string;
  sku: string;
  title: string;
  series: string;
  category: string;
  tag?: string;
  price: number;
  originalPrice: number;
  discountPercent?: number;
  rating: number;
  reviewCount: number;
  description: string;
  colors: ProductColor[];
  sizes: string[];
  stockLeft: number;
  features: {
    title: string;
    desc: string;
    icon: string;
  }[];
  specifications: {
    material: string;
    weight: string;
    fit: string;
    care: string;
    origin: string;
  };
}

export interface Review {
  id: string;
  author: string;
  avatarInitials: string;
  verified: boolean;
  size: string;
  color: string;
  date: string;
  rating: number;
  comment: string;
  fitVote?: 'runs-small' | 'true-to-size' | 'runs-large';
}

export interface CartItem {
  productId: string;
  title: string;
  price: number;
  image: string;
  color: string;
  size: string;
  quantity: number;
}
