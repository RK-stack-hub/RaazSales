---
name: Gear 5 Streetwear
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#37393a'
  surface-container-lowest: '#0c0f0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#c9c5cc'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#928f96'
  outline-variant: '#48464b'
  surface-tint: '#c9c4d2'
  primary: '#c9c4d2'
  on-primary: '#312f39'
  primary-container: '#0f0e17'
  on-primary-container: '#7d7a86'
  inverse-primary: '#5f5d68'
  secondary: '#ddb8ff'
  on-secondary: '#490080'
  secondary-container: '#7c03d3'
  on-secondary-container: '#dfbcff'
  tertiary: '#dfb7ff'
  on-tertiary: '#4a007f'
  tertiary-container: '#1b0033'
  on-tertiary-container: '#9f5add'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#e5e0ee'
  primary-fixed-dim: '#c9c4d2'
  on-primary-fixed: '#1c1a24'
  on-primary-fixed-variant: '#474550'
  secondary-fixed: '#f0dbff'
  secondary-fixed-dim: '#ddb8ff'
  on-secondary-fixed: '#2c0051'
  on-secondary-fixed-variant: '#6800b4'
  tertiary-fixed: '#f1dbff'
  tertiary-fixed-dim: '#dfb7ff'
  on-tertiary-fixed: '#2d0050'
  on-tertiary-fixed-variant: '#661aa3'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  headline-xxl:
    fontFamily: Anton
    fontSize: 72px
    fontWeight: '400'
    lineHeight: 76px
    letterSpacing: -0.02em
  headline-xxl-mobile:
    fontFamily: Anton
    fontSize: 48px
    fontWeight: '400'
    lineHeight: 52px
    letterSpacing: -0.01em
  headline-xl:
    fontFamily: Anton
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 60px
    letterSpacing: -0.02em
  headline-xl-mobile:
    fontFamily: Anton
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg:
    fontFamily: Anton
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 44px
  headline-lg-mobile:
    fontFamily: Anton
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 32px
  headline-md:
    fontFamily: Anton
    fontSize: 24px
    fontWeight: '400'
    lineHeight: 28px
  headline-sm:
    fontFamily: Space Grotesk
    fontSize: 18px
    fontWeight: '700'
    lineHeight: 24px
  body-lg:
    fontFamily: Space Grotesk
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  body-md:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
  body-sm:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '400'
    lineHeight: 16px
  label-lg:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.05em
  label-md:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.05em
  label-sm:
    fontFamily: Space Grotesk
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.08em
spacing:
  gutter: 1.5rem
  margin: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 2rem
  space-xl: 4rem
---

## Brand & Style

This design system channels a high-energy, defiant streetwear aesthetic inspired by the chaotic freedom of Gear 5. The brand personality is rebellious, athletic, expressive, and deeply rooted in modern anime subculture. The target audience consists of fashion-forward Gen Z and millennial enthusiasts who view apparel as a statement of identity. 

The UI evokes a rush of adrenaline—blending dark, moody backdrops with blinding flashes of kinetic purple energy. We utilize a high-contrast dark mode foundation combined with raw, asymmetric grid layouts, oversized typography, and glowing focal points to create an immersive, collectible-driven shopping experience.

## Colors

The palette is anchored by a deep charcoal black background (`#0f0e17`), creating an infinite void that makes high-impact elements leap off the screen. Electric purples (`#9333ea` and `#6b21a8`) act as the pulsing lifeblood of the interface, used for active states, interactive glows, and focal points. Pure white (`#ffffff`) cuts through the dark canvas for maximum legibility on headlines and critical product details. Maintain strict contrast ratios for all body text against the dark surface, reserving the vivid purple spectrum for brand moments and interactive feedback.

## Typography

Typography acts as the primary visual loudspeaker. We pair the commanding, industrial impact of **Anton** for headlines with the technical, geometric precision of **Space Grotesk** for body copy and UI labels. 

 Headlines must always be set in uppercase with tight letter-spacing to emulate heavyweight apparel branding and manga sound-effect typography. Body text prioritizes high readability across fast-paced product browsing sessions, utilizing tracking on smaller labels to enhance the futuristic technical aesthetic.

## Layout & Spacing

The layout is built on a dynamic 12-column fluid grid that breaks conventional boundaries with asymmetric container alignments and overlapping sections. We use generous outer margins (`2rem` desktop, `1rem` mobile) to frame the content like a gallery wall. 

Spacing scales aggressively between tight, technical micro-padding (`space-xs`, `space-sm`) for badges and tags, and massive whitespace gaps (`space-xl`) between distinct narrative drops. On mobile, columns collapse seamlessly into a single-file feed with sticky action bars for uninterrupted checkout flow.

## Elevation & Depth

Depth is communicated through high-contrast outlines and kinetic, glowing ambient shadows rather than traditional skeuomorphic elevation. Surfaces use deep charcoal planes stacked against one another, separated by razor-thin white or low-opacity purple borders. 

Interactive elements and featured product drops leverage vibrant purple ambient glows (`#9333ea` with high blur radii) to simulate an internal energy source. This creates a striking, layered neon-noir atmosphere without relying on muddy drop shadows.

## Shapes

The shape language is strictly sharp (`0px` roundedness) to project an uncompromising, industrial streetwear edge. Buttons, product cards, input fields, and image containers feature hard 90-degree corners, reinforced by sharp border strokes. Occasional accent badges may feature clipped diagonal corners to mimic technical apparel tech-packs and industrial cargo styling.

## Components

### Buttons
Primary action buttons are heavy, uppercase, and sharp-edged, utilizing solid electric purple (`#9333ea`) with high-contrast white text. On hover, they expand their outer purple glow and shift to pure white with black text for maximum visual disruption. Secondary buttons use transparent fills with crisp white outlines that invert on interaction.

### Chips & Tags
Compact and rectangular, used for filtering apparel sizes, drop statuses, or anime chapter nods. Active states snap to a solid purple fill with bold tracking.

### Input Fields
Dark charcoal input boxes featuring stark white borders. When focused, the border transitions instantly to vibrant purple accompanied by a subtle ambient glow, anchoring the user's input in the energetic theme.

### Checkboxes & Radio Buttons
Custom geometric tick-boxes (square for multi-select, diamond for single-select). Unchecked states are hollow charcoal-gray outlines; checked states fill instantly with solid purple and feature a stark white checkmark.

### Cards
Product cards utilize edge-to-edge imagery against the dark background, with sharp borders framing the piece. Typography sits cleanly below the image with oversized pricing and bold collection titles. Hover states trigger a subtle zoom on the product photography and an intensifying purple perimeter glow.

### Additional Components: Drop Timers & Size Matrix
- **Drop Countdowns:** Large tabular display numerals using headline fonts, tracked with glowing colon separators to build hype for limited-edition apparel releases.
- **Size Matrix Grid:** Outlined grid blocks for sizing (S-XXL) that snap into hard white borders when selected, displaying instant stock-level warnings.